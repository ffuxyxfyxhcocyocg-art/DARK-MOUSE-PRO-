package com.darkmouse.pro;

oneway interface IAppCallback {
    void onKey(int code);
    void onRel(int dx, int dy);
    void onLog(String msg);
    void onState(boolean active);
}
