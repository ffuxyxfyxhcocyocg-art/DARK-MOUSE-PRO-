package com.darkmouse.pro;

import com.darkmouse.pro.IAppCallback;

interface IShellService {
    void destroy() = 16777114;
    void setCallback(IAppCallback cb) = 1;
    void setConfig(String json, int w, int h) = 2;
    void setActive(boolean on) = 3;
    void setLearn(boolean on) = 4;
    String status() = 5;
    String foreground() = 6;
    String exec(String cmd) = 7;
    void testTap(float x, float y) = 8;
}
