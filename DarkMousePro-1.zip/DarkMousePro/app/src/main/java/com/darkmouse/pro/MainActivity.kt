package com.darkmouse.pro

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.input.InputManager
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var navBar: LinearLayout
    internal lateinit var games: GameStore

    internal var pendingExport: String? = null
    internal var tester: ((String) -> Unit)? = null
    private var tab = 0
    private val stack = ArrayList<Pair<String, () -> View>>()
    private var overlay: View? = null
    private var appCache: List<AppItem>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refreshRun = Runnable { render() }

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            val d = InputDevice.getDevice(deviceId)
            if (d != null && !d.isVirtual) {
                val kind = Devices.list(this@MainActivity).firstOrNull { it.id == deviceId }?.kind
                if (kind != null) Notif.event(this@MainActivity, 20, "$kind conectado", d.name)
            }
            soon()
        }
        override fun onInputDeviceRemoved(deviceId: Int) {
            Notif.event(this@MainActivity, 21, "Periférico desconectado", "Um dispositivo de entrada foi removido")
            soon()
        }
        override fun onInputDeviceChanged(deviceId: Int) = soon()
    }
    private val binderRecv = Shizuku.OnBinderReceivedListener {
        ShizukuMgr.log("Binder recebido")
        soon()
    }
    private val binderDead = Shizuku.OnBinderDeadListener {
        ShizukuMgr.log("Conexão perdida")
        Notif.event(this, 22, "Shizuku parado", "O serviço Shizuku foi encerrado")
        soon()
    }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, result ->
        ShizukuMgr.log(if (result == PackageManager.PERMISSION_GRANTED) "Autorização concedida" else "Autorização negada")
        if (result != PackageManager.PERMISSION_GRANTED) Notif.event(this, 23, "Permissão negada", "O Shizuku negou a autorização")
        soon()
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        games = GameStore(this)
        Pal.setAccent(getSharedPreferences("ui", Context.MODE_PRIVATE).getInt("accent", Pal.red))
        Notif.init(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7003)
        }

        root = FrameLayout(this)
        root.setBackgroundColor(Pal.bg)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }

        val main = vlist()
        content = FrameLayout(this)
        main.addView(content, lp(MATCH, 0, 1f))
        navBar = LinearLayout(this)
        navBar.orientation = LinearLayout.HORIZONTAL
        navBar.background = box(0xFF0B0B0D.toInt(), Pal.cardLine, 0, 1)
        main.addView(navBar, lp(MATCH, WRAP))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        getSystemService(InputManager::class.java).registerInputDeviceListener(inputListener, handler)
        Shizuku.addBinderReceivedListenerSticky(binderRecv)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)

        render()
    }

    override fun onResume() {
        super.onResume()
        soon()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(refreshRun)
        getSystemService(InputManager::class.java).unregisterInputDeviceListener(inputListener)
        Shizuku.removeBinderReceivedListener(binderRecv)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permResult)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (stack.isNotEmpty()) pop()
        else if (tab != 0) { tab = 0; render() }
        else super.onBackPressed()
    }

    internal fun soon() {
        // não reconstrói telas onde o usuário está digitando
        val top = stack.lastOrNull()?.first
        if (top == "Terminal ADB" || top == "Adicionar jogo") return
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, 150)
    }

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ navegação

    internal fun push(title: String, build: () -> View) {
        stack.add(Pair(title, build))
        render()
    }

    internal fun pop() {
        tester = null
        if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
        render()
    }

    internal fun render() {
        buildNav()
        content.removeAllViews()
        content.addView(
            when (tab) {
                0 -> homeView()
                1 -> gamesTab()
                2 -> toolsTab()
                3 -> settingsTab()
                else -> proTab()
            }
        )
        overlay?.let { root.removeView(it) }
        overlay = null
        val top = stack.lastOrNull()
        if (top != null) {
            val v = screen(top.first, top.second())
            root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
            overlay = v
        }
    }

    private fun buildNav() {
        navBar.removeAllViews()
        val items = listOf("⌂" to "Início", "▣" to "Jogos", "▦" to "Ferramentas", "⚙" to "Config.", "♛" to "Pro+")
        items.forEachIndexed { i, item ->
            val sel = i == tab
            val c = vlist()
            c.gravity = Gravity.CENTER_HORIZONTAL
            if (sel) {
                c.background = GradientDrawable(
                    GradientDrawable.Orientation.BOTTOM_TOP,
                    intArrayOf(0x66FF1E2D, 0x00000000)
                )
            }
            val line = View(this)
            line.setBackgroundColor(if (sel) Pal.red else 0x00000000)
            c.addView(line, lp(dp(30), dp(2)))
            val g = label(item.first, 20f, if (sel) Pal.red else Pal.gray, true)
            g.setPadding(0, dp(6), 0, 0)
            c.addView(g)
            val n = label(item.second, 11f, if (sel) Pal.white else Pal.gray, sel)
            n.setPadding(0, 0, 0, dp(8))
            c.addView(n)
            c.isClickable = true
            c.setOnClickListener { tab = i; stack.clear(); tester = null; render() }
            navBar.addView(c, lp(0, WRAP, 1f))
        }
    }

    private fun screen(title: String, body: View): View {
        val col = vlist()
        col.setBackgroundColor(Pal.bg)
        col.isClickable = true
        val h = hlist()
        h.setPadding(dp(4), dp(8), dp(16), dp(8))
        val back = label("‹", 34f, Pal.red, true)
        back.setPadding(dp(14), 0, dp(14), 0)
        back.setOnClickListener { pop() }
        h.addView(back)
        h.addView(label(title, 20f, Pal.white, true))
        col.addView(h)
        col.addView(body, lp(MATCH, 0, 1f))
        return col
    }

    internal fun scroll(inner: LinearLayout): ScrollView {
        val s = ScrollView(this)
        s.overScrollMode = View.OVER_SCROLL_NEVER
        inner.setPadding(dp(16), dp(8), dp(16), dp(24))
        s.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        return s
    }

    internal fun infoCard(title: String, body: String): View {
        val c = vlist()
        c.background = box(Pal.card, Pal.cardLine, 14)
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.addView(label(title, 15f, Pal.white, true))
        val b = label(body, 13f, Pal.gray)
        b.setPadding(0, dp(4), 0, 0)
        c.addView(b)
        return c
    }

    internal fun comingSoon(title: String, text: String) {
        push(title) {
            val col = vlist()
            col.addView(infoCard("Em desenvolvimento", text))
            scroll(col)
        }
    }

    // ------------------------------------------------------------------ HOME

    private fun homeView(): View {
        val col = vlist()

        // cabeçalho
        val head = hlist()
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_mouse)
        head.addView(logo, lp(dp(54), dp(54)))
        val tcol = vlist()
        val tr = hlist()
        tr.addView(label("DARK", 26f, Pal.white, true))
        tr.addView(label(" MOUSE", 26f, Pal.red, true))
        tr.addView(label(" PRO", 12f, Pal.red, true))
        val sub = label("KEYBOARD & MOUSE MAPPER", 9.5f, Pal.gray)
        sub.letterSpacing = 0.2f
        tcol.addView(tr)
        tcol.addView(sub)
        head.addView(tcol, lp(0, WRAP, 1f, 10, 0, 6, 0))
        val menu = label("≡", 24f, Pal.red, true)
        menu.gravity = Gravity.CENTER
        menu.background = box(Pal.redSoft, Pal.red, 12, 2)
        menu.setOnClickListener { showMenu(it) }
        head.addView(menu, lp(dp(46), dp(46)))
        col.addView(head, lp(MATCH, WRAP, 0f, 0, 0, 0, 14))

        // status (dados reais)
        val devs = Devices.list(this)
        val st = ShizukuMgr.state(this)
        val card = vlist()
        card.background = box(0xFF0A0A0B.toInt(), 0x88FF1E2D.toInt(), 16, 1)
        card.setPadding(dp(8), dp(8), dp(8), dp(8))
        if (devs.isEmpty()) {
            card.addView(
                toolRow("◉", "Nenhum periférico conectado", "O app funciona sem periféricos", Pal.gray) { push("Dispositivos") { devicesView() } },
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        } else {
            val kinds = devs.map { it.kind }.distinct().joinToString(", ")
            card.addView(
                toolRow("◉", "${devs.size} periférico(s) conectado(s)", kinds, Pal.green) { push("Dispositivos") { devicesView() } },
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        }
        card.addView(
            toolRow("⚡", st.title.lowercase().replaceFirstChar { it.uppercase() }, st.hint,
                if (st == SzState.CONECTADO) Pal.green else Pal.yellow) { push("Central Shizuku") { shizukuView() } }
        )
        col.addView(card, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

        // banner
        val ban = hlist()
        val gd = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF140407.toInt(), 0xFF5A0A12.toInt())
        )
        gd.cornerRadius = dp(14).toFloat()
        gd.setStroke(dp(2), Pal.red)
        ban.background = gd
        ban.setPadding(dp(12), dp(14), dp(12), dp(14))
        val crown = label("♛", 24f, Pal.gold, true)
        crown.gravity = Gravity.CENTER
        crown.background = box(0xFF1A1205.toInt(), Pal.gold, 10, 2)
        ban.addView(crown, lp(dp(48), dp(48)))
        val bcol = vlist()
        bcol.addView(label("Dark Mouse PRO+", 17f, Pal.gold, true))
        bcol.addView(label("Recursos extras chegando. Sem anúncios.", 12.5f, Pal.white))
        ban.addView(bcol, lp(0, WRAP, 1f, 12, 0, 8, 0))
        val go = label("›", 22f, Pal.white, true)
        go.gravity = Gravity.CENTER
        go.background = box(Pal.red, Pal.red, 22, 1)
        ban.addView(go, lp(dp(40), dp(40)))
        ban.setOnClickListener { tab = 4; render() }
        col.addView(ban, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        val dots = hlist()
        dots.gravity = Gravity.CENTER
        for (i in 0 until 3) {
            val d = View(this)
            d.setBackgroundColor(if (i == 0) Pal.red else Pal.cardLine)
            dots.addView(d, lp(dp(if (i == 0) 22 else 14), dp(3), 0f, 3, 0, 3, 0))
        }
        col.addView(dots, lp(MATCH, WRAP, 0f, 0, 0, 0, 16))

        // meus jogos
        val gh = hlist()
        gh.addView(sectionTitle("Meus Jogos"), lp(0, WRAP, 1f))
        gh.addView(neonButton("Ver todos ›") { tab = 1; render() })
        col.addView(gh, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val strip = hlist()
        for (pkg in games.all()) {
            val app = Apps.find(this, pkg) ?: continue
            strip.addView(gameCard(app), lp(dp(108), dp(142), 0f, 0, 0, 10, 0))
        }
        strip.addView(addCard(), lp(dp(108), dp(142)))
        hs.addView(strip)
        col.addView(hs, lp(MATCH, WRAP, 0f, 0, 0, 0, 20))

        // ferramentas
        col.addView(sectionTitle("Ferramentas e configurações"), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        addTools(col)

        return scroll(col)
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Central Shizuku")
        pm.menu.add(0, 2, 0, "Dispositivos conectados")
        pm.menu.add(0, 3, 0, "Diagnóstico")
        pm.menu.add(0, 4, 0, "Configurações")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> push("Central Shizuku") { shizukuView() }
                2 -> push("Dispositivos") { devicesView() }
                3 -> push("Diagnóstico") { diagView() }
                else -> { tab = 3; stack.clear(); render() }
            }
            true
        }
        pm.show()
    }

    private fun gameCard(app: AppItem): View {
        val f = FrameLayout(this)
        f.background = box(Pal.card, Pal.red, 16, 2)
        f.isClickable = true
        f.setOnClickListener { if (!Apps.open(this, app.pkg)) toast("Não foi possível abrir") }
        val c = vlist()
        c.gravity = Gravity.CENTER
        c.setPadding(dp(6), dp(10), dp(6), dp(10))
        val ic = ImageView(this)
        ic.setImageDrawable(app.icon)
        c.addView(ic, lp(dp(58), dp(58), 0f, 0, 0, 0, 8))
        val n = label(app.name, 13f, Pal.white, true)
        n.maxLines = 2
        n.ellipsize = TextUtils.TruncateAt.END
        n.gravity = Gravity.CENTER
        c.addView(n)
        f.addView(c, FrameLayout.LayoutParams(MATCH, MATCH))
        val dots = label("⋮", 22f, Pal.gray, true)
        dots.setPadding(dp(10), dp(2), dp(8), dp(6))
        dots.setOnClickListener { gameMenu(it, app) }
        val p = FrameLayout.LayoutParams(WRAP, WRAP)
        p.gravity = Gravity.TOP or Gravity.END
        f.addView(dots, p)
        return f
    }

    internal fun gameMenu(anchor: View, app: AppItem) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Abrir jogo")
        pm.menu.add(0, 2, 0, "Remover da lista")
        pm.setOnMenuItemClickListener {
            if (it.itemId == 1) { if (!Apps.open(this, app.pkg)) toast("Não foi possível abrir") }
            else { games.remove(app.pkg); render() }
            true
        }
        pm.show()
    }

    private fun addCard(): View {
        val c = vlist()
        c.gravity = Gravity.CENTER
        c.background = box(0xFF0A0A0B.toInt(), Pal.cardLine, 16, 1, true)
        val plus = label("+", 30f, Pal.red, true)
        plus.gravity = Gravity.CENTER
        plus.background = box(0x00000000, Pal.red, 30, 2)
        c.addView(plus, lp(dp(56), dp(56), 0f, 0, 0, 0, 8))
        val t = label("Adicionar\nJogo", 13f, Pal.gray)
        t.gravity = Gravity.CENTER
        c.addView(t)
        c.isClickable = true
        c.setOnClickListener { openPicker() }
        return c
    }

    // ------------------------------------------------------------------ ABAS

    private fun gamesTab(): View {
        val col = vlist()
        col.addView(sectionTitle("Meus Jogos"), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        col.addView(neonButton("+ Adicionar jogo (todos os apps do telefone)", true) { openPicker() }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        val list = games.all()
        if (list.isEmpty()) {
            col.addView(infoCard("Nenhum jogo ainda", "Toque em Adicionar jogo e escolha qualquer app instalado."))
        }
        for (pkg in list) {
            val app = Apps.find(this, pkg) ?: continue
            col.addView(
                iconRow(app.icon, app.name, app.pkg, "⋮", { Apps.open(this, app.pkg) }, { gameMenu(it, app) }),
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        }
        return scroll(col)
    }

    private fun toolsTab(): View {
        val col = vlist()
        col.addView(sectionTitle("Ferramentas"), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        addTools(col)
        return scroll(col)
    }

    private fun proTab(): View {
        val col = vlist()
        col.addView(sectionTitle("Pro+"), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        col.addView(
            infoCard(
                "Dark Mouse PRO+ — em breve",
                "Perfis sincronizados e recursos extras estão planejados. Nesta versão não há compra, assinatura nem anúncios."
            )
        )
        return scroll(col)
    }

    // ------------------------------------------------------------------ SELETOR DE APPS

    internal fun openPicker() {
        push("Adicionar jogo") { pickerView() }
    }

    private fun pickerView(): View {
        val col = vlist()
        val search = EditText(this)
        search.hint = "Pesquisar aplicativos"
        search.setHintTextColor(Pal.gray)
        search.setTextColor(Pal.white)
        search.isSingleLine = true
        search.setPadding(dp(14), dp(10), dp(14), dp(10))
        search.background = box(Pal.card, Pal.red, 12, 1)
        col.addView(search, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        val list = vlist()
        col.addView(list)

        fun fill(q: String) {
            list.removeAllViews()
            val src = appCache
            if (src == null) {
                list.addView(label("Carregando apps…", 14f, Pal.gray))
                return
            }
            for (a in src) {
                if (q.isNotBlank() && !a.name.contains(q.trim(), true)) continue
                val added = games.has(a.pkg)
                list.addView(
                    iconRow(a.icon, a.name, a.pkg, if (added) "✓" else "+", {
                        if (games.has(a.pkg)) games.remove(a.pkg) else games.add(a.pkg)
                        fill(search.text.toString())
                    }, null, if (added) Pal.green else Pal.red),
                    lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
                )
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { fill(s?.toString() ?: "") }
        })
        fill("")
        if (appCache == null) {
            Thread {
                val l = Apps.launchable(this)
                runOnUiThread { appCache = l; fill(search.text.toString()) }
            }.start()
        }
        return scroll(col)
    }

    internal fun iconRow(
        icon: Drawable, title: String, sub: String, trailing: String,
        onClick: () -> Unit, onTrailing: ((View) -> Unit)?, trailColor: Int = Pal.gray
    ): View {
        val row = hlist()
        row.background = box(Pal.card, Pal.cardLine, 14)
        row.setPadding(dp(12), dp(10), dp(8), dp(10))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val iv = ImageView(this)
        iv.setImageDrawable(icon)
        row.addView(iv, lp(dp(44), dp(44)))
        val c = vlist()
        val t = label(title, 15f, Pal.white, true)
        t.isSingleLine = true
        t.ellipsize = TextUtils.TruncateAt.END
        val s = label(sub, 11f, Pal.gray)
        s.isSingleLine = true
        s.ellipsize = TextUtils.TruncateAt.END
        c.addView(t)
        c.addView(s)
        row.addView(c, lp(0, WRAP, 1f, 12, 0, 8, 0))
        val tr = label(trailing, 22f, trailColor, true)
        tr.setPadding(dp(12), dp(4), dp(12), dp(4))
        if (onTrailing != null) tr.setOnClickListener { onTrailing(it) }
        row.addView(tr)
        return row
    }

    // ------------------------------------------------------------------ SHIZUKU

    internal fun shizukuView(): View {
        val col = vlist()
        val st = ShizukuMgr.state(this)
        val color = when (st) {
            SzState.CONECTADO -> Pal.green
            SzState.NAO_INSTALADO, SzState.NEGADO -> Pal.red
            else -> Pal.yellow
        }
        val c = vlist()
        c.background = box(Pal.card, color, 14, 2)
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.addView(label(st.title, 18f, color, true))
        c.addView(label(st.hint, 13f, Pal.gray))
        val v = label("Versão: ${ShizukuMgr.version()}", 12f, Pal.gray)
        v.setPadding(0, dp(6), 0, 0)
        c.addView(v)
        col.addView(c, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

        col.addView(neonButton("Autorizar Dark Mouse Pro", true) {
            if (st == SzState.NAO_INSTALADO || st == SzState.PARADO) toast(st.title)
            else ShizukuMgr.requestPermission()
            soon()
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        col.addView(neonButton("Abrir Shizuku") {
            if (!ShizukuMgr.openApp(this)) toast("Shizuku não está instalado")
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        col.addView(neonButton("Verificar novamente") {
            ShizukuMgr.log("Verificação: " + ShizukuMgr.state(this).title)
            render()
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

        col.addView(
            infoCard(
                "Como conectar (sem root)",
                "1. Instale o app Shizuku.\n" +
                    "2. Ative as Opções do desenvolvedor e a Depuração sem fio.\n" +
                    "3. No Shizuku, toque em \"Pareamento\" e informe o código que o Android mostra.\n" +
                    "4. Toque em \"Iniciar\" no Shizuku.\n" +
                    "5. Volte aqui e toque em Autorizar Dark Mouse Pro; confirme no diálogo.\n" +
                    "O Shizuku dá acesso nível shell (ADB), não root. O app nunca se autoriza sozinho."
            ),
            lp(MATCH, WRAP, 0f, 0, 0, 0, 12)
        )
        val hist = ShizukuMgr.history()
        col.addView(infoCard("Histórico de conexão", if (hist.isEmpty()) "Sem eventos ainda." else hist.joinToString("\n")))
        return scroll(col)
    }

    // ------------------------------------------------------------------ DISPOSITIVOS

    internal fun devicesView(): View {
        val col = vlist()
        col.addView(sectionTitle("Entrada (teclado / mouse / gamepad)"), lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        val devs = Devices.list(this)
        if (devs.isEmpty()) col.addView(infoCard("Nenhum periférico", "Conecte por USB OTG ou Bluetooth. Esta lista atualiza sozinha."))
        for (d in devs) {
            col.addView(
                infoCard("${d.kind}: ${d.name}", "id ${d.id}  •  VID:PID %04X:%04X".format(d.vendor, d.product)),
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        }
        col.addView(sectionTitle("USB (host)"), lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        val um = getSystemService(Context.USB_SERVICE) as UsbManager
        val usb = um.deviceList.values.toList()
        if (usb.isEmpty()) col.addView(infoCard("Nenhum dispositivo USB", "Use um cabo/adaptador OTG."))
        for (u in usb) {
            col.addView(
                infoCard(u.deviceName, "VID:PID %04X:%04X  •  classe ${u.deviceClass}".format(u.vendorId, u.productId)),
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        }
        col.addView(
            infoCard("Bluetooth", "Teclados, mouses e controles Bluetooth pareados aparecem na lista de entrada acima quando conectados.")
        )
        return scroll(col)
    }

    // ------------------------------------------------------------------ TERMINAL

    internal fun terminalView(): View {
        val col = vlist()
        val input = EditText(this)
        input.hint = "ex: pm list packages -3"
        input.setHintTextColor(Pal.gray)
        input.setTextColor(Pal.white)
        input.typeface = Typeface.MONOSPACE
        input.setPadding(dp(14), dp(10), dp(14), dp(10))
        input.background = box(Pal.card, Pal.red, 12, 1)
        col.addView(input, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        val out = label("", 12f, Pal.green)
        out.typeface = Typeface.MONOSPACE
        out.setTextIsSelectable(true)
        col.addView(neonButton("Executar", true) {
            val cmd = input.text.toString().trim()
            if (cmd.isNotEmpty()) {
                if (ShizukuMgr.state(this) != SzState.CONECTADO) {
                    out.text = "Shizuku não está conectado/autorizado. Abra a Central Shizuku."
                } else {
                    out.text = "executando…"
                    Thread {
                        val r = ShizukuMgr.exec(cmd)
                        runOnUiThread { out.text = r }
                    }.start()
                }
            }
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        col.addView(out)
        return scroll(col)
    }

    // ------------------------------------------------------------------ DIAGNÓSTICO

    private fun diagText(): String {
        val dm = resources.displayMetrics
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val devs = Devices.list(this)
        val pmgr = packageManager
        return listOf(
            "Dark Mouse Pro 1.0.0",
            "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Aparelho: ${Build.MANUFACTURER} ${Build.MODEL}",
            "Tela: ${dm.widthPixels}x${dm.heightPixels} @ ${dm.densityDpi} dpi",
            "RAM livre: ${mi.availMem / 1048576} MB de ${mi.totalMem / 1048576} MB",
            "USB host (OTG): " + if (pmgr.hasSystemFeature(PackageManager.FEATURE_USB_HOST)) "sim" else "não",
            "Bluetooth: " + if (pmgr.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) "sim" else "não",
            "Shizuku: ${ShizukuMgr.state(this).title} — ${ShizukuMgr.version()}",
            "Teclado: " + if (devs.any { it.kind == "Teclado" }) "conectado" else "não detectado",
            "Mouse: " + if (devs.any { it.kind == "Mouse" }) "conectado" else "não detectado",
            "Gamepad: " + if (devs.any { it.kind == "Gamepad" }) "conectado" else "não detectado",
            "Jogos na lista: ${games.all().size}"
        ).joinToString("\n")
    }

    internal fun diagView(): View {
        val col = vlist()
        val text = diagText()
        val t = label(text, 13f, Pal.white)
        t.typeface = Typeface.MONOSPACE
        t.setTextIsSelectable(true)
        val c = vlist()
        c.background = box(Pal.card, Pal.cardLine, 14)
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.addView(t)
        col.addView(c, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        col.addView(neonButton("Atualizar") { render() }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        col.addView(neonButton("Compartilhar relatório", true) {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(i, "Relatório"))
        })
        return scroll(col)
    }

    // ------------------------------------------------------------------ testadores e arquivos

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val t = tester
        if (t != null && e.action == KeyEvent.ACTION_DOWN && e.keyCode != KeyEvent.KEYCODE_BACK) {
            t("Tecla: " + KeyEvent.keyCodeToString(e.keyCode) + " (" + e.keyCode + ")\nDispositivo: " + (e.device?.name ?: "?") +
                "\nRepetição: " + e.repeatCount + "\nMeta: " + e.metaState)
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        val t = tester
        if (t != null) {
            val sb = StringBuilder("Dispositivo: " + (e.device?.name ?: "?") + "\n")
            if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                sb.append("Analógico esq: %.2f , %.2f\n".format(e.getAxisValue(MotionEvent.AXIS_X), e.getAxisValue(MotionEvent.AXIS_Y)))
                sb.append("Analógico dir: %.2f , %.2f\n".format(e.getAxisValue(MotionEvent.AXIS_Z), e.getAxisValue(MotionEvent.AXIS_RZ)))
                sb.append("Gatilhos: %.2f , %.2f\n".format(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_RTRIGGER)))
                sb.append("D-Pad: %.0f , %.0f".format(e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y)))
            } else {
                sb.append("Posição: %.0f , %.0f\n".format(e.x, e.y))
                sb.append("Botões: ").append(e.buttonState).append('\n')
                sb.append("Scroll: %.1f".format(e.getAxisValue(MotionEvent.AXIS_VSCROLL)))
            }
            t(sb.toString())
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        val t = tester
        if (t != null) {
            t("Toque/clique: " + (if (e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) "MOUSE" else "dedo") +
                "\nPosição: %.0f , %.0f".format(e.x, e.y) + "\nBotões (máscara): " + e.buttonState +
                "\n(1=esquerdo 2=direito 4=meio)")
        }
        return super.dispatchTouchEvent(e)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        try {
            if (req == 7002) {
                contentResolver.openOutputStream(uri)?.use { it.write((pendingExport ?: "").toByteArray()) }
                pendingExport = null
                toast("Exportado")
            } else if (req == 7001) {
                val txt = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                toast(BackupManager.restore(this, ProfileStore(this), games, txt))
                render()
            }
        } catch (ex: Exception) {
            toast("Erro: " + ex.message)
        }
    }
}
