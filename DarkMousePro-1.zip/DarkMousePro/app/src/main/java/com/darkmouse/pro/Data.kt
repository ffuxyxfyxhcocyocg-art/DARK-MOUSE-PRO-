package com.darkmouse.pro

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.hardware.input.InputManager
import android.view.InputDevice

/** Um app instalado que tem ícone no launcher. */
class AppItem(val pkg: String, val name: String, val icon: Drawable)

object Apps {
    /** Todos os apps com atividade de launcher (precisa de QUERY_ALL_PACKAGES no Android 11+). */
    fun launchable(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val list = pm.queryIntentActivities(intent, 0)
        val out = ArrayList<AppItem>()
        val seen = HashSet<String>()
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            out.add(AppItem(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
        }
        out.sortBy { it.name.lowercase() }
        return out
    }

    fun find(ctx: Context, pkg: String): AppItem? {
        return try {
            val pm = ctx.packageManager
            val ai = pm.getApplicationInfo(pkg, 0)
            AppItem(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
        } catch (e: Exception) {
            null
        }
    }

    fun open(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}

/** Lista de jogos escolhidos pelo usuário (só nomes de pacote, local). */
class GameStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("games", Context.MODE_PRIVATE)

    fun all(): List<String> {
        val s = p.getString("list", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split(",")
    }

    private fun save(l: List<String>) {
        p.edit().putString("list", l.joinToString(",")).apply()
    }

    fun has(pkg: String) = all().contains(pkg)
    fun add(pkg: String) { if (!has(pkg)) save(all() + pkg) }
    fun remove(pkg: String) { save(all().filter { it != pkg }) }
}

class Dev(val id: Int, val name: String, val kind: String, val vendor: Int, val product: Int)

object Devices {
    /** Dispositivos de entrada reais reportados pelo Android (InputManager). */
    fun list(ctx: Context): List<Dev> {
        val im = ctx.getSystemService(InputManager::class.java)
        val out = ArrayList<Dev>()
        for (id in im.inputDeviceIds) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            val s = d.sources
            val kind = when {
                (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                    (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK -> "Gamepad"
                (s and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE -> "Mouse"
                (s and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                    d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC -> "Teclado"
                else -> null
            } ?: continue
            out.add(Dev(id, d.name, kind, d.vendorId, d.productId))
        }
        return out
    }
}
