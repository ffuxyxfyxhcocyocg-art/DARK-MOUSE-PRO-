package com.darkmouse.pro

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    val bg = 0xFF050505.toInt()
    val card = 0xFF101012.toInt()
    val cardLine = 0xFF2A2A2E.toInt()
    var red = 0xFFFF1E2D.toInt()
    var redSoft = 0xFF1C0509.toInt()
    val white = 0xFFFFFFFF.toInt()
    val gray = 0xFF9A9AA0.toInt()
    val green = 0xFF2ECC71.toInt()
    val gold = 0xFFF5B63A.toInt()
    val yellow = 0xFFFFC107.toInt()

    fun setAccent(c: Int) {
        red = c
        redSoft = Color.rgb(Color.red(c) / 9, Color.green(c) / 9, Color.blue(c) / 9)
    }
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.box(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int = 1, dashed: Boolean = false): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (dashed) g.setStroke(dp(strokeDp), stroke, dp(6).toFloat(), dp(4).toFloat())
    else g.setStroke(dp(strokeDp), stroke)
    return g
}

fun Context.label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

fun Context.vlist(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hlist(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(l), dp(t), dp(r), dp(b))
    return p
}

/** Cabeçalho de seção com barrinha vermelha, como na referência. */
fun Context.sectionTitle(text: String): View {
    val row = hlist()
    val bar = View(this)
    bar.setBackgroundColor(Pal.red)
    row.addView(bar, lp(dp(4), dp(22), 0f, 0, 0, 10, 0))
    row.addView(label(text, 20f, Pal.white, true))
    return row
}

/** Cartão de ferramenta: ícone em caixa vermelha + título + descrição + seta. */
fun Context.toolRow(glyph: String, title: String, sub: String, accent: Int = Pal.red, onClick: () -> Unit): View {
    val row = hlist()
    row.background = box(Pal.card, Pal.cardLine, 14)
    row.setPadding(dp(12), dp(12), dp(14), dp(12))
    row.isClickable = true
    row.setOnClickListener { onClick() }

    val ic = label(glyph, 20f, accent, true)
    ic.gravity = Gravity.CENTER
    ic.background = box(Pal.redSoft, accent, 10, 2)
    row.addView(ic, lp(dp(48), dp(48)))

    val col = vlist()
    col.addView(label(title, 16f, Pal.white, true))
    col.addView(label(sub, 12.5f, Pal.gray))
    row.addView(col, lp(0, WRAP, 1f, 12, 0, 8, 0))

    row.addView(label("›", 26f, Pal.gray))
    return row
}

fun Context.neonButton(text: String, filled: Boolean = false, onClick: () -> Unit): TextView {
    val b = label(text, 14f, if (filled) Pal.white else Pal.red, true)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(16), dp(11), dp(16), dp(11))
    b.background = box(if (filled) Pal.red else Pal.redSoft, Pal.red, 12, 1)
    b.isClickable = true
    b.setOnClickListener { onClick() }
    return b
}
