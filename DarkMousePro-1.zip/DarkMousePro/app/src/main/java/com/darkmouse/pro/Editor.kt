package com.darkmouse.pro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import kotlin.math.min
import kotlin.math.roundToInt

private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

/**
 * Editor visual de layout, desenhado por cima da tela real do jogo (janela de sobreposição).
 * Arraste os controles; use a barra de baixo para tecla, tamanho, opacidade, rotação etc.
 */
class EditorOverlay(
    private val ctx: Context,
    private val store: ProfileStore,
    private val profile: Profile,
    private val engine: MapEngine?,
    private val onClose: () -> Unit
) : FrameLayout(ctx) {

    private var sel: Control? = null
    private var grid = true
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()
    private val info = TextView(ctx)
    private val surface: Surface
    private val main = Handler(Looper.getMainLooper())

    init {
        surface = Surface(ctx)
        addView(surface, LayoutParams(MATCH, MATCH))

        info.setTextColor(Pal.white)
        info.textSize = 12f
        info.typeface = Typeface.DEFAULT_BOLD
        info.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6))
        info.background = ctx.box(0xCC000000.toInt(), Pal.red, 10, 1)
        val ip = LayoutParams(WRAP, WRAP)
        ip.gravity = Gravity.TOP or Gravity.START
        ip.setMargins(ctx.dp(10), ctx.dp(10), 0, 0)
        addView(info, ip)

        val bp = LayoutParams(MATCH, WRAP)
        bp.gravity = Gravity.BOTTOM
        addView(buildPanel(), bp)
        refreshInfo()
    }

    private fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------- histórico

    private fun snapshot(): String = profile.toJson().toString()

    private fun pushUndo() {
        undo.add(snapshot())
        if (undo.size > 60) undo.removeAt(0)
        redo.clear()
    }

    private fun applySnapshot(s: String) {
        val np = Profile.fromJson(JSONObject(s))
        profile.controls.clear()
        profile.controls.addAll(np.controls)
        profile.sensH = np.sensH; profile.sensV = np.sensV
        profile.invertX = np.invertX; profile.invertY = np.invertY
        sel = null
    }

    private fun doUndo() {
        if (undo.isEmpty()) return
        redo.add(snapshot())
        applySnapshot(undo.removeAt(undo.size - 1))
    }

    private fun doRedo() {
        if (redo.isEmpty()) return
        undo.add(snapshot())
        applySnapshot(redo.removeAt(redo.size - 1))
    }

    // ------------------------------------------------------------- ações

    private fun add(type: Int) {
        pushUndo()
        val c = Control(type, 0.5f, 0.5f)
        when (type) {
            CT.BUTTON -> { c.size = 0.09f; c.label = "Botão" }
            CT.JOYSTICK -> c.size = 0.30f
            CT.CAMERA -> c.size = 0.35f
        }
        profile.controls.add(c)
        sel = c
    }

    private fun dup() {
        val s = sel ?: return
        pushUndo()
        val c = s.copy()
        c.x = (c.x + 0.03f).coerceAtMost(1f)
        c.y = (c.y + 0.03f).coerceAtMost(1f)
        profile.controls.add(c)
        sel = c
    }

    private fun del() {
        val s = sel ?: return
        pushUndo()
        profile.controls.remove(s)
        sel = null
    }

    private fun resize(f: Float) {
        val s = sel ?: return
        pushUndo()
        s.size = (s.size * f).coerceIn(0.04f, 0.7f)
    }

    private fun opacity(d: Float) {
        val s = sel ?: return
        pushUndo()
        s.alpha = (s.alpha + d).coerceIn(0.15f, 1f)
    }

    private fun rotate() {
        val s = sel ?: return
        pushUndo()
        s.rot = (s.rot + 15f) % 360f
    }

    private fun toggleTap() {
        val s = sel ?: return
        if (s.type != CT.BUTTON) return
        pushUndo()
        s.tap = !s.tap
    }

    private fun done() {
        surface.invalidate()
        refreshInfo()
    }

    private fun pick(capture: Boolean) {
        val c = sel ?: run { toast("Selecione um controle"); return }
        pushUndo()
        when (c.type) {
            CT.JOYSTICK ->
                getKey("CIMA", capture) { k1 -> c.kUp = k1
                    getKey("BAIXO", capture) { k2 -> c.kDown = k2
                        getKey("ESQUERDA", capture) { k3 -> c.kLeft = k3
                            getKey("DIREITA", capture) { k4 -> c.kRight = k4; done() }
                        }
                    }
                }
            CT.CAMERA -> toast("A câmera usa o movimento do mouse (ou o analógico direito).")
            else -> getKey("a tecla", capture) { k -> c.key = k; done() }
        }
    }

    private fun getKey(what: String, capture: Boolean, cb: (Int) -> Unit) {
        if (capture) {
            val e = engine
            if (e == null) { toast("Captura precisa do Shizuku conectado. Use \"Tecla (lista)\"."); return }
            toast("Pressione $what (teclado, mouse ou controle)…")
            e.capture = { code -> main.post { cb(code) } }
        } else {
            showKeyList(what, cb)
        }
    }

    private fun showKeyList(what: String, cb: (Int) -> Unit) {
        val dlg = ctx.vlist()
        dlg.background = ctx.box(0xF0101012.toInt(), Pal.red, 14, 2)
        dlg.setPadding(ctx.dp(12), ctx.dp(12), ctx.dp(12), ctx.dp(12))
        dlg.addView(ctx.label("Escolha $what", 14f, Pal.white, true))
        val sv = ScrollView(ctx)
        val list = ctx.vlist()
        for (e in Keys.table.entries.sortedBy { it.key }) {
            val t = ctx.label(e.value, 15f, Pal.white)
            t.setPadding(ctx.dp(8), ctx.dp(9), ctx.dp(8), ctx.dp(9))
            val code = e.key
            t.setOnClickListener { removeView(dlg); cb(code) }
            list.addView(t)
        }
        sv.addView(list)
        dlg.addView(sv, LinearLayout.LayoutParams(ctx.dp(240), ctx.dp(220)))
        val lp = LayoutParams(WRAP, WRAP)
        lp.gravity = Gravity.CENTER
        addView(dlg, lp)
    }

    // ------------------------------------------------------------- painel

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = ctx.label(text, 12f, Pal.white, true)
        t.setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(8))
        t.background = ctx.box(Pal.redSoft, Pal.red, 10, 1)
        t.setOnClickListener {
            onClick()
            surface.invalidate()
            refreshInfo()
        }
        return t
    }

    private fun row(vararg chips: TextView): HorizontalScrollView {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val l = ctx.hlist()
        for (c in chips) l.addView(c, ctx.lp(WRAP, WRAP, 0f, 3, 3, 3, 3))
        hs.addView(l)
        return hs
    }

    private fun buildPanel(): View {
        val col = ctx.vlist()
        col.setBackgroundColor(0xE6050505.toInt())
        col.setPadding(ctx.dp(6), ctx.dp(4), ctx.dp(6), ctx.dp(4))
        col.addView(row(
            chip("+ Botão") { add(CT.BUTTON) },
            chip("+ Joystick") { add(CT.JOYSTICK) },
            chip("+ Câmera") { add(CT.CAMERA) },
            chip("Duplicar") { dup() },
            chip("Excluir") { del() },
            chip("Tecla (capturar)") { pick(true) },
            chip("Tecla (lista)") { pick(false) }
        ))
        col.addView(row(
            chip("Tam −") { resize(0.9f) },
            chip("Tam +") { resize(1.1f) },
            chip("Opac −") { opacity(-0.1f) },
            chip("Opac +") { opacity(0.1f) },
            chip("Girar") { rotate() },
            chip("Toque/Segurar") { toggleTap() },
            chip("Grade") { grid = !grid }
        ))
        col.addView(row(
            chip("Desfazer") { doUndo() },
            chip("Refazer") { doRedo() },
            chip("Sens H −") { profile.sensH = (profile.sensH - 0.1f).coerceAtLeast(0.1f) },
            chip("Sens H +") { profile.sensH = (profile.sensH + 0.1f).coerceAtMost(5f) },
            chip("Sens V −") { profile.sensV = (profile.sensV - 0.1f).coerceAtLeast(0.1f) },
            chip("Sens V +") { profile.sensV = (profile.sensV + 0.1f).coerceAtMost(5f) },
            chip("Inverter X") { profile.invertX = !profile.invertX },
            chip("Inverter Y") { profile.invertY = !profile.invertY }
        ))
        col.addView(row(
            chip("Salvar") { store.save(profile); toast("Layout salvo") },
            chip("Salvar e sair") { store.save(profile); toast("Layout salvo"); onClose() },
            chip("Sair sem salvar") { onClose() }
        ))
        return col
    }

    private fun refreshInfo() {
        val c = sel
        info.text = if (c != null) {
            val k = when (c.type) {
                CT.JOYSTICK -> Keys.name(c.kUp) + Keys.name(c.kLeft) + Keys.name(c.kDown) + Keys.name(c.kRight)
                CT.CAMERA -> "mouse"
                else -> Keys.name(c.key)
            }
            "${CT.name(c.type)} • $k • tam ${(c.size * 100).roundToInt()}% • opac ${(c.alpha * 100).roundToInt()}% • " +
                "rot ${c.rot.roundToInt()}° • " + (if (c.type == CT.BUTTON) (if (c.tap) "toque" else "segurar") else "")
        } else {
            "Toque num controle • SensH %.1f SensV %.1f • %d controles".format(profile.sensH, profile.sensV, profile.controls.size)
        }
    }

    // ------------------------------------------------------------- desenho

    inner class Surface(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private var dragging = false

        init {
            line.style = Paint.Style.STROKE
            txt.color = Color.WHITE
            txt.textAlign = Paint.Align.CENTER
            txt.typeface = Typeface.DEFAULT_BOLD
        }

        private fun dash(on: Boolean) {
            line.pathEffect = if (on) DashPathEffect(floatArrayOf(ctx.dp(8).toFloat(), ctx.dp(6).toFloat()), 0f) else null
        }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            cv.drawColor(0x55000000)
            if (grid) {
                line.color = 0x22FFFFFF
                line.strokeWidth = 1f
                var gx = 0f
                while (gx <= w) { cv.drawLine(gx, 0f, gx, h, line); gx += w / 20f }
                var gy = 0f
                while (gy <= h) { cv.drawLine(0f, gy, w, gy, line); gy += h / 12f }
            }
            line.strokeWidth = ctx.dp(2).toFloat()
            txt.textSize = ctx.dp(13).toFloat()
            txt.color = Color.WHITE
            cv.drawText("EDITOR — arraste os controles sobre o jogo", w / 2f, ctx.dp(24).toFloat(), txt)

            for (c in profile.controls) {
                val cx = c.x * w
                val cy = c.y * h
                val r = c.size * min(w, h) / 2f
                val a = (c.alpha * 255).toInt()
                cv.save()
                cv.rotate(c.rot, cx, cy)
                when (c.type) {
                    CT.JOYSTICK -> {
                        fill.color = withAlpha(Pal.red, (a * 0.18f).toInt())
                        cv.drawCircle(cx, cy, r, fill)
                        line.color = withAlpha(Pal.red, a)
                        cv.drawCircle(cx, cy, r, line)
                        fill.color = withAlpha(Pal.red, (a * 0.45f).toInt())
                        cv.drawCircle(cx, cy, r * 0.35f, fill)
                        txt.color = withAlpha(Color.WHITE, a)
                        txt.textSize = (r * 0.22f).coerceIn(ctx.dp(10).toFloat(), ctx.dp(20).toFloat())
                        cv.drawText(Keys.name(c.kUp), cx, cy - r * 0.68f, txt)
                        cv.drawText(Keys.name(c.kDown), cx, cy + r * 0.80f, txt)
                        cv.drawText(Keys.name(c.kLeft), cx - r * 0.70f, cy + txt.textSize / 3f, txt)
                        cv.drawText(Keys.name(c.kRight), cx + r * 0.70f, cy + txt.textSize / 3f, txt)
                    }
                    CT.CAMERA -> {
                        line.color = withAlpha(Pal.red, a)
                        dash(true)
                        cv.drawCircle(cx, cy, r, line)
                        dash(false)
                        cv.drawLine(cx - r * 0.25f, cy, cx + r * 0.25f, cy, line)
                        cv.drawLine(cx, cy - r * 0.25f, cx, cy + r * 0.25f, line)
                        txt.color = withAlpha(Color.WHITE, a)
                        txt.textSize = ctx.dp(12).toFloat()
                        cv.drawText("CÂMERA", cx, cy + r * 0.55f, txt)
                    }
                    else -> {
                        fill.color = withAlpha(Pal.red, (a * 0.35f).toInt())
                        cv.drawCircle(cx, cy, r, fill)
                        line.color = withAlpha(Pal.red, a)
                        cv.drawCircle(cx, cy, r, line)
                        txt.color = withAlpha(Color.WHITE, a)
                        txt.textSize = (r * 0.5f).coerceIn(ctx.dp(10).toFloat(), ctx.dp(20).toFloat())
                        val t = if (c.type == CT.MACRO) "M " + Keys.name(c.key) else Keys.name(c.key)
                        cv.drawText(t, cx, cy + txt.textSize / 3f, txt)
                        if (c.label.isNotEmpty()) {
                            txt.textSize = ctx.dp(10).toFloat()
                            cv.drawText(c.label, cx, cy + r + ctx.dp(12), txt)
                        }
                    }
                }
                cv.restore()
                if (c === sel) {
                    line.color = Color.WHITE
                    dash(true)
                    cv.drawCircle(cx, cy, r + ctx.dp(6), line)
                    dash(false)
                }
            }
        }

        private fun hit(x: Float, y: Float): Control? {
            val w = width.toFloat()
            val h = height.toFloat()
            for (i in profile.controls.indices.reversed()) {
                val c = profile.controls[i]
                val r = maxOf(c.size * min(w, h) / 2f, ctx.dp(24).toFloat())
                val dx = x - c.x * w
                val dy = y - c.y * h
                if (dx * dx + dy * dy <= r * r) return c
            }
            return null
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sel = hit(e.x, e.y)
                    if (sel != null) { pushUndo(); dragging = true }
                    invalidate(); refreshInfo()
                }
                MotionEvent.ACTION_MOVE -> {
                    val c = sel
                    if (dragging && c != null && width > 0 && height > 0) {
                        var nx = (e.x / width).coerceIn(0f, 1f)
                        var ny = (e.y / height).coerceIn(0f, 1f)
                        if (grid) {
                            nx = (nx * 40f).roundToInt() / 40f
                            ny = (ny * 24f).roundToInt() / 24f
                        }
                        c.x = nx; c.y = ny
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            }
            return true
        }
    }
}
