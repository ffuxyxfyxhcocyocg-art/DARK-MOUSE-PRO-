package com.darkmouse.pro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Backup/restauração de perfis, lista de jogos e ajustes, com verificação de integridade (SHA-256). */
object BackupManager {

    fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun build(ctx: Context, store: ProfileStore, games: GameStore, only: List<Profile>? = null): String {
        val payload = JSONObject()
        val arr = JSONArray()
        for (p in (only ?: store.all())) arr.put(p.toJson())
        payload.put("profiles", arr)
        val g = JSONArray()
        for (pkg in games.all()) g.put(pkg)
        payload.put("games", g)
        val ui = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
        val u = JSONObject()
        u.put("mouseGain", ui.getFloat("mouseGain", 1f).toDouble())
        u.put("deadzone", ui.getFloat("deadzone", 0.15f).toDouble())
        u.put("accent", ui.getInt("accent", 0xFFFF1E2D.toInt()))
        payload.put("ui", u)
        val ps = payload.toString()
        val doc = JSONObject()
        doc.put("app", "DarkMousePro")
        doc.put("v", 1)
        doc.put("sha256", sha(ps))
        doc.put("payload", ps)
        return doc.toString()
    }

    /** Devolve uma mensagem para mostrar ao usuário. Só altera dados se a verificação passar. */
    fun restore(ctx: Context, store: ProfileStore, games: GameStore, doc: String): String {
        try {
            val d = JSONObject(doc)
            if (d.optString("app") != "DarkMousePro") return "Arquivo inválido: não é um backup do Dark Mouse Pro."
            val ps = d.getString("payload")
            if (sha(ps) != d.getString("sha256")) return "Falha na verificação de integridade: arquivo alterado ou corrompido. Nada foi restaurado."
            val pl = JSONObject(ps)
            var n = 0
            val arr = pl.optJSONArray("profiles")
            if (arr != null) for (i in 0 until arr.length()) {
                store.save(Profile.fromJson(arr.getJSONObject(i)))
                n++
            }
            val g = pl.optJSONArray("games")
            if (g != null) for (i in 0 until g.length()) games.add(g.getString(i))
            val u = pl.optJSONObject("ui")
            if (u != null) {
                ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).edit()
                    .putFloat("mouseGain", u.optDouble("mouseGain", 1.0).toFloat())
                    .putFloat("deadzone", u.optDouble("deadzone", 0.15).toFloat())
                    .apply()
            }
            return "Restaurado: $n perfil(is)."
        } catch (e: Exception) {
            return "Arquivo corrompido: " + (e.message ?: "erro de leitura")
        }
    }

    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "backups")
        d.mkdirs()
        return d
    }

    fun local(ctx: Context, store: ProfileStore, games: GameStore): File {
        val name = "backup-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".json"
        val f = File(dir(ctx), name)
        f.writeText(build(ctx, store, games))
        return f
    }

    fun listLocal(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray()).filter { it.name.endsWith(".json") }.sortedByDescending { it.name }
}
