package com.darkmouse.pro

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- helpers

fun MainActivity.ui() = getSharedPreferences("ui", Context.MODE_PRIVATE)

fun MainActivity.defaultPkg(): String? {
    val store = ProfileStore(this)
    val last = ui().getString("lastPkg", null)
    if (last != null && games.has(last) && store.forPkg(last).isNotEmpty()) return last
    return games.all().firstOrNull { store.forPkg(it).isNotEmpty() }
}

fun MainActivity.ensureOverlay(): Boolean {
    if (Settings.canDrawOverlays(this)) return true
    toast("Ative \"Sobrepor a outros apps\" para o Dark Mouse Pro e volte.")
    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    return false
}

fun MainActivity.startMappingFor(pkg: String) {
    if (!ensureOverlay()) return
    if (ShizukuMgr.state(this) != SzState.CONECTADO) {
        toast("Conecte e autorize o Shizuku primeiro.")
        push("Central Shizuku") { shizukuView() }
        return
    }
    if (ProfileStore(this).activeFor(pkg) == null) {
        toast("Crie um mapeamento para esse jogo primeiro.")
        return
    }
    MappingService.start(this, "start", pkg)
    Apps.open(this, pkg)
}

fun MainActivity.editFor(pkg: String) {
    if (!ensureOverlay()) return
    MappingService.start(this, "edit", pkg)
    Apps.open(this, pkg)
}

fun MainActivity.askText(title: String, initial: String, multiline: Boolean = false, cb: (String) -> Unit) {
    val et = EditText(this)
    et.setText(initial)
    et.setTextColor(Pal.white)
    if (multiline) {
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.minLines = 5
        et.typeface = Typeface.MONOSPACE
        et.gravity = Gravity.TOP
    } else {
        et.isSingleLine = true
    }
    AlertDialog.Builder(this)
        .setTitle(title)
        .setView(et)
        .setPositiveButton("OK") { _, _ -> cb(et.text.toString()) }
        .setNegativeButton("Cancelar", null)
        .show()
}

fun MainActivity.pickKey(cb: (Int) -> Unit) {
    val entries = Keys.table.entries.sortedBy { it.key }
    val names = entries.map { it.value }.toTypedArray()
    AlertDialog.Builder(this)
        .setTitle("Escolha a tecla")
        .setItems(names) { _, i -> cb(entries[i].key) }
        .show()
}

fun MainActivity.exportText(fileName: String, text: String) {
    pendingExport = text
    val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
    i.addCategory(Intent.CATEGORY_OPENABLE)
    i.type = "application/json"
    i.putExtra(Intent.EXTRA_TITLE, fileName)
    @Suppress("DEPRECATION")
    startActivityForResult(i, 7002)
}

fun MainActivity.importFile() {
    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
    i.addCategory(Intent.CATEGORY_OPENABLE)
    i.type = "*/*"
    @Suppress("DEPRECATION")
    startActivityForResult(i, 7001)
}

fun MainActivity.slider(title: String, min: Float, max: Float, key: String, def: Float): View {
    val c = vlist()
    c.background = box(Pal.card, Pal.cardLine, 14)
    c.setPadding(dp(14), dp(12), dp(14), dp(12))
    val prefs = ui()
    val v = prefs.getFloat(key, def)
    val t = label("%s: %.2f".format(title, v), 14f, Pal.white, true)
    c.addView(t)
    val sb = SeekBar(this)
    sb.max = 100
    sb.progress = (((v - min) / (max - min)) * 100).toInt().coerceIn(0, 100)
    sb.progressTintList = ColorStateList.valueOf(Pal.red)
    sb.thumbTintList = ColorStateList.valueOf(Pal.red)
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            val nv = min + (max - min) * p / 100f
            prefs.edit().putFloat(key, nv).apply()
            t.text = "%s: %.2f".format(title, nv)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    c.addView(sb)
    return c
}

fun MainActivity.toggleRow(title: String, sub: String, key: String, def: Boolean): View {
    val row = hlist()
    row.background = box(Pal.card, Pal.cardLine, 14)
    row.setPadding(dp(14), dp(12), dp(14), dp(12))
    val col = vlist()
    col.addView(label(title, 15f, Pal.white, true))
    col.addView(label(sub, 12f, Pal.gray))
    row.addView(col, lp(0, WRAP, 1f, 0, 0, 8, 0))
    val sw = Switch(this)
    sw.isChecked = ui().getBoolean(key, def)
    sw.setOnCheckedChangeListener { _, c -> ui().edit().putBoolean(key, c).apply() }
    row.addView(sw)
    return row
}

// ---------------------------------------------------------------- ferramentas

fun MainActivity.addTools(col: LinearLayout) {
    val gap = 10
    fun add(v: View) = col.addView(v, lp(MATCH, WRAP, 0f, 0, 0, 0, gap))

    if (MappingService.mapping) {
        add(toolRow("■", "PARAR mapeamento", "Mapeamento ativo agora.", Pal.green) {
            MappingService.start(this, "stop")
            toast("Parando…")
        })
    } else {
        add(toolRow("▶", "INICIAR mapeamento", "Usa o perfil do último jogo e abre o painel flutuante.") {
            val p = defaultPkg()
            if (p == null) toast("Adicione um jogo e crie um mapeamento primeiro.") else startMappingFor(p)
        })
    }
    add(toolRow("✥", "Mapeamentos", "Criar, editar, exportar e importar layouts.") { push("Mapeamentos") { mappingsView() } })
    add(toolRow("⌗", "Macros", "Sequências de toques com atalho de tecla.") { push("Macros") { macrosView() } })
    add(toolRow(">_", "Terminal ADB", "Execute comandos shell (via Shizuku).") { push("Terminal ADB") { terminalView() } })
    add(toolRow("▦", "Apps em execução", "Ver e forçar parada de apps.") { push("Apps em execução") { runningView() } })
    add(toolRow("⚡", "Central Shizuku", "Status, autorização e tutorial.") { push("Central Shizuku") { shizukuView() } })
    add(toolRow("⌁", "Central ADB", "Depuração, depuração sem fio e diagnóstico.") { push("Central ADB") { adbView() } })
    add(toolRow("◉", "Dispositivos conectados", "Teclado, mouse, gamepad e USB.") { push("Dispositivos") { devicesView() } })
    add(toolRow("⌨", "Testadores", "Teclado, mouse e controle.") { push("Testadores") { testerView() } })
    add(toolRow("◎", "Calibração", "Sensibilidade do mouse e zona morta do analógico.") { push("Calibração") { calibView() } })
    add(toolRow("✚", "Diagnóstico", "Informações do aparelho e relatório.") { push("Diagnóstico") { diagView() } })
    add(toolRow("⛁", "Backup e restauração", "Salvar e restaurar perfis e ajustes.") { push("Backup") { backupView() } })
    add(toolRow("?", "Central de ajuda", "Tutoriais, perguntas e limitações.") { push("Ajuda") { helpView() } })
}

// ---------------------------------------------------------------- mapeamentos

fun MainActivity.mappingsView(): View {
    val col = vlist()
    val store = ProfileStore(this)
    val list = games.all()
    col.addView(
        infoCard(
            "Como funciona",
            "1) Crie um layout para o jogo (FPS, MOBA ou personalizado).\n" +
                "2) Toque em Editar layout: o editor aparece por cima do jogo.\n" +
                "3) Toque em Iniciar: o app converte teclado/mouse/controle em toques.\n" +
                "Requer Shizuku conectado e a permissão de sobreposição."
        ), lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    col.addView(neonButton("Importar perfil / backup (.json)") { importFile() }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
    if (list.isEmpty()) col.addView(infoCard("Sem jogos", "Adicione um jogo na aba Jogos primeiro."))
    for (pkg in list) {
        val app = Apps.find(this, pkg) ?: continue
        col.addView(sectionTitle(app.name), lp(MATCH, WRAP, 0f, 0, 6, 0, 8))
        val row = hlist()
        row.addView(neonButton("+ FPS") { store.save(Templates.fps(pkg).also { store.setActive(it) }); render() }, lp(0, WRAP, 1f, 0, 0, 6, 0))
        row.addView(neonButton("+ MOBA") { store.save(Templates.moba(pkg).also { store.setActive(it) }); render() }, lp(0, WRAP, 1f, 0, 0, 6, 0))
        row.addView(neonButton("+ Livre") { store.save(Templates.custom(pkg).also { store.setActive(it) }); render() }, lp(0, WRAP, 1f))
        col.addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val act = store.activeFor(pkg)
        for (p in store.forPkg(pkg)) {
            val isAct = act?.id == p.id
            val sub = p.mode + " • " + p.controls.size + " controles" + (if (p.favorite) " • ★" else "") + (if (isAct) " • ATIVO" else "")
            col.addView(
                iconRow(app.icon, p.name, sub, "⋮", {
                    store.setActive(p)
                    toast("Perfil ativo: " + p.name)
                    render()
                }, { v -> profileMenu(v, store, app, p) }, if (isAct) Pal.green else Pal.gray),
                lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
            )
        }
        val b = hlist()
        b.addView(neonButton("Editar layout", true) {
            if (store.activeFor(pkg) == null) store.save(Templates.fps(pkg).also { store.setActive(it) })
            editFor(pkg)
        }, lp(0, WRAP, 1f, 0, 0, 6, 0))
        b.addView(neonButton("Iniciar", true) { startMappingFor(pkg) }, lp(0, WRAP, 1f))
        col.addView(b, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
    }
    return scroll(col)
}

fun MainActivity.profileMenu(anchor: View, store: ProfileStore, app: AppItem, p: Profile) {
    val pm = PopupMenu(this, anchor)
    pm.menu.add(0, 1, 0, "Definir como ativo")
    pm.menu.add(0, 2, 0, "Editar layout")
    pm.menu.add(0, 3, 0, "Renomear")
    pm.menu.add(0, 4, 0, "Duplicar")
    pm.menu.add(0, 5, 0, if (p.favorite) "Remover favorito" else "Favoritar")
    pm.menu.add(0, 6, 0, "Exportar")
    pm.menu.add(0, 7, 0, "Excluir")
    pm.setOnMenuItemClickListener {
        when (it.itemId) {
            1 -> { store.setActive(p); render() }
            2 -> { store.setActive(p); editFor(p.pkg) }
            3 -> askText("Renomear perfil", p.name) { n -> if (n.isNotBlank()) { p.name = n.trim(); store.save(p); render() } }
            4 -> { store.duplicate(p); render() }
            5 -> { p.favorite = !p.favorite; store.save(p); render() }
            6 -> exportText("perfil-" + p.name.replace(Regex("[^A-Za-z0-9]+"), "_") + ".json", BackupManager.build(this, store, games, listOf(p)))
            7 -> AlertDialog.Builder(this)
                .setTitle("Excluir \"" + p.name + "\"?")
                .setPositiveButton("Excluir") { _, _ -> store.delete(p.id); render() }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        true
    }
    pm.show()
}

// ---------------------------------------------------------------- macros

fun MainActivity.macrosView(): View {
    val col = vlist()
    val store = ProfileStore(this)
    col.addView(
        infoCard(
            "Macros",
            "Uma macro é uma sequência curta de toques nos controles do perfil, disparada por uma tecla.\n" +
                "Cada linha: número_do_controle, tempo_segurando_ms, espera_depois_ms\n" +
                "Ex.: \"3,60,150\" toca o controle 3 por 60 ms e espera 150 ms.\n" +
                "Máx. 12 passos, sem repetição automática. Recarregue o mapeamento após editar."
        ), lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    var any = false
    for (pkg in games.all()) {
        val p = store.activeFor(pkg) ?: continue
        val app = Apps.find(this, pkg) ?: continue
        any = true
        col.addView(sectionTitle(app.name + " — " + p.name), lp(MATCH, WRAP, 0f, 0, 6, 0, 8))
        val idx = StringBuilder()
        p.controls.forEachIndexed { i, c -> idx.append(i + 1).append(" = ").append(CT.name(c.type)).append(' ').append(Keys.name(c.key)).append('\n') }
        col.addView(infoCard("Controles do perfil", idx.toString().trim().ifEmpty { "(vazio)" }), lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        for (c in p.controls.filter { it.type == CT.MACRO }) {
            val card = vlist()
            card.background = box(Pal.card, if (c.on) Pal.red else Pal.cardLine, 14, 1)
            card.setPadding(dp(12), dp(10), dp(12), dp(10))
            card.addView(label("Macro • tecla " + Keys.name(c.key) + if (c.on) "" else " (desativada)", 14f, Pal.white, true))
            val st = label(c.steps.ifBlank { "(sem passos)" }, 12f, Pal.gray)
            st.typeface = Typeface.MONOSPACE
            card.addView(st)
            val r = hlist()
            fun save() { store.save(p); if (MappingService.mapping) MappingService.start(this, "start", p.pkg); render() }
            r.addView(neonButton("Passos") { askText("Passos da macro", c.steps, true) { s -> c.steps = s.trim(); save() } }, lp(WRAP, WRAP, 0f, 0, 6, 6, 0))
            r.addView(neonButton("Tecla") { pickKey { k -> c.key = k; save() } }, lp(WRAP, WRAP, 0f, 0, 6, 6, 0))
            r.addView(neonButton("Testar") {
                if (!(MappingService.instance?.testMacro(p, c) ?: false)) toast("Inicie o mapeamento deste jogo para testar.")
            }, lp(WRAP, WRAP, 0f, 0, 6, 6, 0))
            r.addView(neonButton(if (c.on) "Desativar" else "Ativar") { c.on = !c.on; save() }, lp(WRAP, WRAP, 0f, 0, 6, 6, 0))
            r.addView(neonButton("Excluir") { p.controls.remove(c); save() }, lp(WRAP, WRAP, 0f, 0, 6, 0, 0))
            card.addView(r)
            col.addView(card, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        }
        col.addView(neonButton("+ Nova macro", true) {
            val m = Control(CT.MACRO, 0.5f, 0.08f)
            m.size = 0.05f
            m.alpha = 0.4f
            m.label = "Macro"
            p.controls.add(m)
            store.save(p)
            render()
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
    }
    if (!any) col.addView(infoCard("Sem perfis", "Crie um mapeamento em Ferramentas > Mapeamentos antes."))
    return scroll(col)
}

// ---------------------------------------------------------------- apps em execução

fun MainActivity.runningView(): View {
    val col = vlist()
    if (ShizukuMgr.state(this) != SzState.CONECTADO) {
        col.addView(infoCard("Shizuku necessário", "Conecte e autorize o Shizuku para listar e parar apps."))
        return scroll(col)
    }
    val holder = vlist()
    col.addView(neonButton("Atualizar") { render() }, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    col.addView(holder)
    holder.addView(label("Carregando…", 14f, Pal.gray))
    Thread {
        val out = ShizukuMgr.exec("ps -A -o USER,NAME | grep '^u0_a'")
        val names = out.lines()
            .map { it.trim().split(Regex("\\s+")) }
            .filter { it.size >= 2 }
            .map { it[1] }
            .filter { it.contains('.') && !it.contains(':') && it != packageName }
            .distinct()
        runOnUiThread {
            holder.removeAllViews()
            if (names.isEmpty()) holder.addView(infoCard("Nada encontrado", out.take(300)))
            for (n in names) {
                val app = Apps.find(this, n) ?: continue
                holder.addView(
                    iconRow(app.icon, app.name, app.pkg, "■", { }, { _ ->
                        Thread {
                            ShizukuMgr.exec("am force-stop " + app.pkg)
                            runOnUiThread { toast("Parado: " + app.name); render() }
                        }.start()
                    }, Pal.red),
                    lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
                )
            }
        }
    }.start()
    return scroll(col)
}

// ---------------------------------------------------------------- Central ADB

fun MainActivity.adbView(): View {
    val col = vlist()
    fun gi(k: String): Int = try { Settings.Global.getInt(contentResolver, k, 0) } catch (e: Exception) { 0 }
    val dev = gi("development_settings_enabled") == 1
    val adb = gi("adb_enabled") == 1
    val wifi = gi("adb_wifi_enabled") == 1
    val st = ShizukuMgr.state(this)
    val txt = "Opções do desenvolvedor: " + (if (dev) "ativadas" else "desativadas") + "\n" +
        "Depuração USB: " + (if (adb) "ativada" else "desativada") + "\n" +
        "Depuração sem fio: " + (if (wifi) "ativada" else "desativada") + "\n" +
        "Shizuku: " + st.title + "\n" +
        "Privilégio disponível: " + (if (st == SzState.CONECTADO) "shell (ADB) via Shizuku" else "nenhum")
    col.addView(infoCard("Diagnóstico de conexão", txt), lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    col.addView(neonButton("Abrir opções do desenvolvedor", true) {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { toast("Não foi possível abrir") }
    }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(neonButton("Central Shizuku") { push("Central Shizuku") { shizukuView() } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    col.addView(
        infoCard(
            "Se não conecta",
            "• A depuração sem fio exige Wi‑Fi ligado (pode ser só um roteador sem internet).\n" +
                "• Depois de reiniciar o aparelho o Shizuku precisa ser iniciado de novo.\n" +
                "• Se o pareamento falhar, desligue e ligue a depuração sem fio e gere um novo código.\n" +
                "• O app não guarda códigos de pareamento."
        ), lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    val h = ShizukuMgr.history()
    col.addView(infoCard("Histórico de erros e eventos", if (h.isEmpty()) "Sem eventos." else h.joinToString("\n")))
    return scroll(col)
}

// ---------------------------------------------------------------- testadores

fun MainActivity.testerView(): View {
    val col = vlist()
    val out = label("Pressione teclas, mova/clique o mouse ou use o controle.\nOs dados aparecem aqui.", 13f, Pal.green)
    out.typeface = Typeface.MONOSPACE
    val c = vlist()
    c.background = box(Pal.card, Pal.red, 14, 1)
    c.setPadding(dp(14), dp(12), dp(14), dp(12))
    c.addView(out)
    col.addView(c, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    tester = { s -> out.text = s }
    col.addView(infoCard("Dica", "Teclado: mostra código e dispositivo. Mouse: posição, botões e scroll. Controle: eixos e D-Pad."))
    return scroll(col)
}

fun MainActivity.calibView(): View {
    val col = vlist()
    col.addView(slider("Velocidade do mouse (global)", 0.2f, 3f, "mouseGain", 1f), lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    col.addView(slider("Zona morta do analógico", 0f, 0.5f, "deadzone", 0.15f), lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
    col.addView(
        infoCard(
            "Sensibilidade por jogo",
            "A sensibilidade horizontal/vertical e a inversão de eixos ficam no Editor de layout (barra de baixo), " +
                "salvas separadamente em cada perfil."
        ), lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    col.addView(neonButton("Abrir testadores", true) { push("Testadores") { testerView() } })
    return scroll(col)
}

// ---------------------------------------------------------------- backup

fun MainActivity.backupView(): View {
    val col = vlist()
    val store = ProfileStore(this)
    col.addView(
        infoCard("Backup", "Salva perfis, lista de jogos e ajustes com verificação SHA-256. Arquivos locais ficam na pasta privada do app."),
        lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    col.addView(neonButton("Criar backup local", true) {
        val f = BackupManager.local(this, store, games)
        toast("Salvo: " + f.name)
        render()
    }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(neonButton("Exportar backup para arquivo") {
        val name = "dark-mouse-pro-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json"
        exportText(name, BackupManager.build(this, store, games))
    }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(neonButton("Importar de arquivo") { importFile() }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
    col.addView(sectionTitle("Backups locais"), lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    val files: List<File> = BackupManager.listLocal(this)
    if (files.isEmpty()) col.addView(infoCard("Nenhum backup", "Crie o primeiro acima."))
    for (f in files) {
        col.addView(toolRow("↺", f.name, "Toque para restaurar • " + (f.length() / 1024 + 1) + " KB") {
            AlertDialog.Builder(this)
                .setTitle("Restaurar este backup?")
                .setMessage("Perfis com o mesmo ID serão sobrescritos.")
                .setPositiveButton("Restaurar") { _, _ ->
                    toast(BackupManager.restore(this, store, games, f.readText()))
                    render()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    }
    return scroll(col)
}

// ---------------------------------------------------------------- ajuda

private val HELP: List<Pair<String, String>> = listOf(
    "Tutorial inicial" to "1. Aba Jogos > Adicionar jogo: escolha o app.\n2. Conecte o Shizuku (Central Shizuku).\n3. Ferramentas > Mapeamentos: crie um layout para o jogo e edite.\n4. Toque em Iniciar. Use o botão flutuante para pausar, editar ou parar.\n5. F10 pausa/retoma o mapeamento (útil para digitar no chat).",
    "Tutorial Shizuku" to "1. Instale o app Shizuku.\n2. Ative Opções do desenvolvedor (toque 7x no número da versão).\n3. Ative Depuração sem fio (Wi‑Fi ligado).\n4. No Shizuku: Pareamento > informe o código do Android > Iniciar.\n5. Volte aqui e toque em Autorizar. Após reiniciar o aparelho, inicie o Shizuku de novo.",
    "Tutorial USB OTG" to "Use um adaptador/cabo OTG. Ao plugar teclado, mouse ou controle, ele aparece em Dispositivos conectados. Se não aparecer, teste outro cabo/porta e verifique se o aparelho suporta USB host (Diagnóstico).",
    "Tutorial Bluetooth" to "Pareie o teclado, mouse ou controle em Configurações do Android > Bluetooth. Quando conectar, ele aparece em Dispositivos conectados e nos testadores.",
    "Tutorial de mapeamento" to "No editor: toque num controle para selecionar, arraste para mover. Use Tam/Opac/Girar na barra. \"Tecla (capturar)\" lê a próxima tecla/clique/botão físico; \"Tecla (lista)\" escolhe de uma lista. Joystick: define 4 teclas de direção. Câmera: o movimento do mouse (ou analógico direito) vira um dedo arrastando nessa área.",
    "Perguntas frequentes" to "• Por que precisa do Shizuku? Android não deixa apps comuns injetarem toques em outros apps; o Shizuku dá acesso nível ADB.\n• Dá ban? O app só gera toques como um dedo, não lê nem altera memória do jogo, mas cada jogo tem suas regras sobre ferramentas de mapeamento. Use por sua conta.\n• Funciona sem Shizuku? A lista de jogos, dispositivos, editor e perfis sim; o mapeamento em si não.",
    "Limitações do Android" to "• Sem Shizuku não há injeção de toque.\n• O cursor do mouse do Android continua existindo e os cliques/teclas também chegam ao jogo normalmente; alguns jogos reagem a isso, outros ignoram.\n• A latência depende do aparelho e do Shizuku.\n• Alguns jogos ignoram ou tratam de forma diferente entrada injetada.\n• Não testado em todos os aparelhos/versões. Compatibilidade real só testando.",
    "Permissões" to "• Ver todos os apps: montar a lista de jogos.\n• Sobrepor a outros apps: botão flutuante e editor.\n• Notificações: avisos de eventos e serviço ativo.\n• Shizuku: você autoriza dentro do app Shizuku.\nNada é enviado para a internet."
)

fun MainActivity.helpView(): View {
    val col = vlist()
    for ((t, b) in HELP) {
        col.addView(toolRow("?", t, "Toque para abrir") { push(t) { scroll(vlist().also { l -> l.addView(infoCard(t, b)) }) } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    }
    return scroll(col)
}

// ---------------------------------------------------------------- abas

fun MainActivity.settingsTab(): View {
    val col = vlist()
    col.addView(sectionTitle("Configurações"), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

    col.addView(label("Cor do tema", 14f, Pal.white, true), lp(MATCH, WRAP, 0f, 0, 0, 0, 6))
    val sw = hlist()
    for (c in intArrayOf(0xFFFF1E2D.toInt(), 0xFFFF6A00.toInt(), 0xFF2E8BFF.toInt(), 0xFF9B4DFF.toInt(), 0xFF22C55E.toInt())) {
        val v = View(this)
        v.background = box(c, if (c == Pal.red) Pal.white else c, 20, 2)
        v.setOnClickListener {
            ui().edit().putInt("accent", c).apply()
            Pal.setAccent(c)
            render()
        }
        sw.addView(v, lp(dp(40), dp(40), 0f, 0, 0, 10, 0))
    }
    col.addView(sw, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

    col.addView(toggleRow("Notificações", "Avisos de dispositivos, Shizuku e perfis.", "notif", true), lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(toggleRow("Troca automática de perfil", "Muda o perfil conforme o jogo em primeiro plano (precisa Shizuku, consulta a cada 2,5 s).", "autoSwitch", false), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))

    val ov = Settings.canDrawOverlays(this)
    col.addView(
        toolRow("▣", "Sobreposição: " + (if (ov) "concedida" else "NÃO concedida"), "Necessária para o botão flutuante e o editor.", if (ov) Pal.green else Pal.red) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8)
    )
    col.addView(toolRow("◎", "Calibração", "Mouse e analógico.") { push("Calibração") { calibView() } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(toolRow("⛁", "Backup e restauração", "Perfis e ajustes.") { push("Backup") { backupView() } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(toolRow("?", "Central de ajuda", "Tutoriais e limitações.") { push("Ajuda") { helpView() } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(toolRow("↑", "Versão e atualização", "Instalada: 1.0.0") { push("Versão") { updateView() } }, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
    col.addView(toolRow("⚙", "Configurações do Android", "Permissões deste app.") {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    })
    return scroll(col)
}

fun MainActivity.updateView(): View {
    val col = vlist()
    col.addView(
        infoCard(
            "Dark Mouse Pro 1.0.0",
            "Build " + Build.VERSION.SDK_INT + " • código 1\nNovas versões são instaladas manualmente por você; o app nunca atualiza sozinho nem acessa a internet."
        ), lp(MATCH, WRAP, 0f, 0, 0, 0, 10)
    )
    col.addView(infoCard("Histórico", "1.0.0 — Primeira versão: jogos, dispositivos, Shizuku, editor de layout, mapeamento por injeção de toque, macros, perfis, backup, testadores."))
    return scroll(col)
}
