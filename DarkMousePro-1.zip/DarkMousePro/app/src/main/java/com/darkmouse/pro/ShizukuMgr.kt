package com.darkmouse.pro

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SzState(val title: String, val hint: String) {
    NAO_INSTALADO("SHIZUKU NÃO INSTALADO", "Instale o app Shizuku para usar os recursos avançados."),
    PARADO("SHIZUKU PARADO", "Abra o Shizuku e inicie o serviço (depuração sem fio)."),
    AGUARDANDO("AGUARDANDO AUTORIZAÇÃO", "Toque em Autorizar e confirme no diálogo do Shizuku."),
    NEGADO("PERMISSÃO NEGADA", "Libere o Dark Mouse Pro na lista de apps autorizados do Shizuku."),
    CONECTADO("CONECTADO", "Serviço ativo e autorizado."),
}

object ShizukuMgr {
    const val PKG = "moe.shizuku.privileged.api"
    private val history = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(msg: String) {
        history.add(0, fmt.format(Date()) + "  " + msg)
        if (history.size > 50) history.removeAt(history.size - 1)
    }

    fun history(): List<String> = history

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun state(ctx: Context): SzState {
        if (!installed(ctx)) return SzState.NAO_INSTALADO
        return try {
            if (!Shizuku.pingBinder()) SzState.PARADO
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) SzState.CONECTADO
            else if (Shizuku.shouldShowRequestPermissionRationale()) SzState.NEGADO
            else SzState.AGUARDANDO
        } catch (e: Throwable) {
            SzState.PARADO
        }
    }

    fun version(): String = try {
        if (Shizuku.pingBinder()) "API ${Shizuku.getVersion()} (uid ${Shizuku.getUid()})" else "—"
    } catch (e: Throwable) {
        "—"
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
                log("Solicitando autorização")
                Shizuku.requestPermission(1001)
            } else log("Serviço parado: não dá para solicitar")
        } catch (e: Throwable) {
            log("Erro ao solicitar: ${e.message}")
        }
    }

    fun openApp(ctx: Context): Boolean {
        val i: Intent = ctx.packageManager.getLaunchIntentForPackage(PKG) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }

    /** Cria um processo com o privilégio do Shizuku (shell/ADB). */
    fun spawn(cmd: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    /** Executa um comando shell e devolve a saída. Só chamar com state == CONECTADO. */
    fun exec(cmd: String): String {
        return try {
            val p = spawn(arrayOf("sh", "-c", "$cmd 2>&1"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.ifEmpty { "(sem saída)" }
        } catch (e: Throwable) {
            "Erro: ${e.cause?.message ?: e.message}"
        }
    }
}
