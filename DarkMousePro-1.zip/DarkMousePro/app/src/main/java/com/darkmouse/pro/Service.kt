package com.darkmouse.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

object Notif {
    const val CH_SVC = "dm_service"
    const val CH_EVT = "dm_events"

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SVC, "Mapeamento ativo", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_EVT, "Eventos do app", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun event(ctx: Context, id: Int, title: String, text: String) {
        if (!ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).getBoolean("notif", true)) return
        try {
            init(ctx)
            val n = Notification.Builder(ctx, CH_EVT)
                .setSmallIcon(R.drawable.ic_mouse)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) {
            /* sem permissão de notificação: ignora */
        }
    }
}

/**
 * Serviço em primeiro plano: mantém o motor de mapeamento, o painel flutuante e o editor.
 * Ações: start / stop / edit / quit.
 */
class MappingService : Service() {

    companion object {
        @Volatile var instance: MappingService? = null
        @Volatile var mapping = false

        fun start(ctx: Context, action: String, pkg: String? = null) {
            val i = Intent(ctx, MappingService::class.java)
            i.action = action
            if (pkg != null) i.putExtra("pkg", pkg)
            ctx.startForegroundService(i)
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var store: ProfileStore
    private var inj: TouchInjector? = null
    private var engine: MapEngine? = null
    private var raw: RawInput? = null
    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var statusTv: TextView? = null
    private var editor: EditorOverlay? = null
    private var pkg: String? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var watching = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        store = ProfileStore(this)
        Notif.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val a = intent?.action
        val pk = intent?.getStringExtra("pkg")
        when (a) {
            "start" -> startMapping(pk)
            "stop" -> {
                stopMapping()
                if (bubble == null && editor == null) quit()
            }
            "edit" -> openEditor(pk)
            "quit" -> quit()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanup()
        instance = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun startFg() {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, Notif.CH_SVC)
            .setSmallIcon(R.drawable.ic_mouse)
            .setContentTitle("Dark Mouse Pro")
            .setContentText("Mapeamento e painel flutuante em execução")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    // ------------------------------------------------------------- motor

    private fun updateScreen(e: MapEngine) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(0).getRealMetrics(dm)
        e.screenW = dm.widthPixels
        e.screenH = dm.heightPixels
    }

    private fun ensureEngine(): Boolean {
        if (engine != null) return true
        if (ShizukuMgr.state(this) != SzState.CONECTADO) {
            toast("Shizuku não está conectado/autorizado.")
            return false
        }
        val t = TouchInjector()
        if (!t.init()) {
            toast("Falha ao iniciar a injeção de toque: " + (t.error ?: "desconhecida"))
            return false
        }
        inj = t
        val e = MapEngine(t, getSharedPreferences("ui", Context.MODE_PRIVATE))
        e.onPause = { p -> main.post { updateStatus(); if (p) toast("Mapeamento PAUSADO (F10)") else toast("Mapeamento RETOMADO") } }
        engine = e
        raw = RawInput(e)
        return true
    }

    private fun ensureRaw() {
        val r = raw ?: return
        if (!r.running) {
            r.start { err ->
                main.post {
                    toast("Leitura de entrada falhou: $err")
                    mapping = false
                    updateStatus()
                }
            }
        }
    }

    private fun startMapping(pk: String?) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Conceda a permissão de sobreposição ao Dark Mouse Pro.")
            return
        }
        val ui = getSharedPreferences("ui", Context.MODE_PRIVATE)
        pkg = pk ?: ui.getString("lastPkg", null)
        showBubble()
        if (!ensureEngine()) return
        val e = engine ?: return
        val pkgName = pkg
        val p = if (pkgName != null) store.activeFor(pkgName) else null
        if (p == null) {
            toast("Esse jogo ainda não tem mapeamento. Crie um em Ferramentas > Mapeamentos.")
            return
        }
        ui.edit().putString("lastPkg", pkgName).apply()
        updateScreen(e)
        e.setProfile(p)
        ensureRaw()
        mapping = true
        updateStatus()
        Notif.event(this, 10, "Perfil ativado", p.name)
        startWatcher()
    }

    private fun stopMapping() {
        watching = false
        raw?.stop()
        engine?.release()
        mapping = false
        updateStatus()
    }

    /** Troca automática de perfil: olha qual app está em primeiro plano (via Shizuku). */
    private fun startWatcher() {
        if (watching) return
        if (!getSharedPreferences("ui", Context.MODE_PRIVATE).getBoolean("autoSwitch", false)) return
        watching = true
        Thread {
            val rx = Regex("u0 ([A-Za-z0-9_.]+)/")
            while (watching) {
                try {
                    val out = ShizukuMgr.exec("dumpsys window | grep mCurrentFocus")
                    val fg = rx.find(out)?.groupValues?.get(1)
                    if (fg != null && fg != pkg && fg != packageName) {
                        val p = store.activeFor(fg)
                        if (p != null) {
                            pkg = fg
                            engine?.setProfile(p)
                            main.post { Notif.event(this, 11, "Perfil ativado", p.name) }
                        }
                    }
                    Thread.sleep(2500)
                } catch (e: Throwable) {
                    break
                }
            }
        }.start()
    }

    fun testMacro(p: Profile, c: Control): Boolean {
        val e = engine ?: return false
        if (!mapping) return false
        e.runMacro(p, c)
        return true
    }

    // ------------------------------------------------------------- editor

    private fun fullParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        return lp
    }

    private fun openEditor(pk: String?) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Conceda a permissão de sobreposição ao Dark Mouse Pro.")
            return
        }
        val pkgName = pk ?: pkg ?: return
        pkg = pkgName
        var p = store.activeFor(pkgName)
        if (p == null) {
            p = Templates.fps(pkgName)
            store.save(p)
            store.setActive(p)
        }
        val ok = ensureEngine()
        val e = if (ok) engine else null
        if (e != null) {
            updateScreen(e)
            e.paused = true
            ensureRaw()
        }
        closeEditor(false)
        hidePanel()
        val ed = EditorOverlay(this, store, p, e) { closeEditor(true) }
        wm.addView(ed, fullParams())
        editor = ed
        showBubble()
    }

    private fun closeEditor(reload: Boolean) {
        val ed = editor ?: return
        try { wm.removeView(ed) } catch (e: Exception) { /* já removido */ }
        editor = null
        val e = engine
        if (e != null) {
            e.capture = null
            val pkgName = pkg
            if (reload && pkgName != null) e.setProfile(store.activeFor(pkgName))
            if (mapping) e.paused = false else raw?.stop()
        }
        if (!mapping && bubble == null) quit()
    }

    // ------------------------------------------------------------- bolha e painel

    private fun showBubble() {
        if (bubble != null) return
        val b = ImageView(this)
        b.setImageResource(R.drawable.ic_mouse)
        b.setPadding(dp(8), dp(8), dp(8), dp(8))
        b.background = box(0xCC000000.toInt(), Pal.red, 24, 2)
        val lp = WindowManager.LayoutParams(
            dp(48), dp(48), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(120)
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - sx
                    val dy = ev.rawY - sy
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try { wm.updateViewLayout(b, lp) } catch (e: Exception) { /* ignora */ }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
        bubbleLp = lp
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { /* ignora */ } }
        panel = null
        statusTv = null
    }

    private fun togglePanel() {
        if (panel != null) { hidePanel(); return }
        val col = vlist()
        col.background = box(0xEE0A0A0B.toInt(), Pal.red, 14, 2)
        col.setPadding(dp(10), dp(10), dp(10), dp(10))
        col.addView(label("DARK MOUSE PRO", 13f, Pal.red, true))
        val st = label("", 12f, Pal.white, true)
        st.setPadding(0, dp(2), 0, dp(8))
        col.addView(st)
        statusTv = st
        val gap = 6
        col.addView(neonButton(if (mapping) "Parar mapeamento" else "Iniciar mapeamento", true) {
            hidePanel()
            if (mapping) stopMapping() else startMapping(pkg)
        }, lp(WRAP, WRAP, 0f, 0, 0, 0, gap))
        col.addView(neonButton(if (engine?.paused == true) "Retomar (F10)" else "Pausar (F10)") {
            hidePanel()
            val e = engine
            if (e != null) { e.paused = !e.paused; if (e.paused) e.release(); updateStatus() }
        }, lp(WRAP, WRAP, 0f, 0, 0, 0, gap))
        col.addView(neonButton("Editar layout") {
            hidePanel()
            openEditor(pkg)
        }, lp(WRAP, WRAP, 0f, 0, 0, 0, gap))
        col.addView(neonButton("Abrir Dark Mouse Pro") {
            hidePanel()
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }, lp(WRAP, WRAP, 0f, 0, 0, 0, gap))
        col.addView(neonButton("Encerrar") { hidePanel(); quit() })
        val bl = bubbleLp
        val lp = WindowManager.LayoutParams(
            WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (bl?.x ?: 0) + dp(56)
        lp.y = bl?.y ?: dp(120)
        wm.addView(col, lp)
        panel = col
        updateStatus()
    }

    private fun updateStatus() {
        val s = statusTv ?: return
        val e = engine
        s.text = when {
            !mapping -> "PARADO"
            e?.paused == true -> "PAUSADO"
            else -> "ATIVO"
        }
    }

    private fun quit() {
        stopMapping()
        closeEditor(false)
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup() {
        watching = false
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { /* ignora */ } }
        bubble = null
        editor?.let { try { wm.removeView(it) } catch (e: Exception) { /* ignora */ } }
        editor = null
        raw?.stop()
        engine?.shutdown()
        engine = null
        raw = null
        mapping = false
    }
}
