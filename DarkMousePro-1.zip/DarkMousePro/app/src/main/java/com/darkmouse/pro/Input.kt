package com.darkmouse.pro

import android.content.SharedPreferences
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Injeta toques via o serviço "input" do sistema, usando o Binder do Shizuku.
 * Só funciona com o Shizuku conectado e autorizado.
 */
class TouchInjector {
    private var svc: Any? = null
    private var inject: Method? = null
    private class P(val id: Int, var x: Float, var y: Float)

    private val active = ArrayList<P>()
    private var downTime = 0L

    @Volatile var error: String? = null
    @Volatile var ready = false

    fun init(): Boolean {
        return try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            val binder: IBinder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            val s = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
                ?: throw IllegalStateException("serviço input indisponível")
            svc = s
            inject = s.javaClass.methods.first { it.name == "injectInputEvent" && it.parameterTypes.size == 2 }
            ready = true
            true
        } catch (e: Throwable) {
            error = e.cause?.message ?: e.message ?: e.toString()
            ready = false
            false
        }
    }

    @Synchronized
    fun down(id: Int, x: Float, y: Float) {
        val ex = active.firstOrNull { it.id == id }
        if (ex != null) {
            ex.x = x; ex.y = y
            send(MotionEvent.ACTION_MOVE)
            return
        }
        val first = active.isEmpty()
        if (first) downTime = SystemClock.uptimeMillis()
        active.add(P(id, x, y))
        active.sortBy { it.id }
        val idx = active.indexOfFirst { it.id == id }
        send(
            if (first) MotionEvent.ACTION_DOWN
            else (MotionEvent.ACTION_POINTER_DOWN or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        )
    }

    @Synchronized
    fun move(id: Int, x: Float, y: Float) {
        val p = active.firstOrNull { it.id == id } ?: return
        p.x = x; p.y = y
        send(MotionEvent.ACTION_MOVE)
    }

    @Synchronized
    fun up(id: Int) {
        val idx = active.indexOfFirst { it.id == id }
        if (idx < 0) return
        val last = active.size == 1
        send(
            if (last) MotionEvent.ACTION_UP
            else (MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        )
        active.removeAt(idx)
    }

    @Synchronized
    fun releaseAll() {
        while (active.isNotEmpty()) up(active[0].id)
    }

    private fun send(action: Int) {
        val n = active.size
        val props = Array(n) { i ->
            val pp = MotionEvent.PointerProperties()
            pp.id = active[i].id
            pp.toolType = MotionEvent.TOOL_TYPE_FINGER
            pp
        }
        val coords = Array(n) { i ->
            val c = MotionEvent.PointerCoords()
            c.x = active[i].x
            c.y = active[i].y
            c.pressure = 1f
            c.size = 1f
            c
        }
        val now = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(
            downTime, now, action, n, props, coords, 0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            inject?.invoke(svc, ev, 0)
        } catch (e: Throwable) {
            error = e.cause?.message ?: e.message
        } finally {
            ev.recycle()
        }
    }
}

interface InputSink {
    fun key(code: Int, down: Boolean)
    fun rel(dx: Int, dy: Int)
    fun abs(code: Int, value: Int)
}

/** Lê eventos brutos de /dev/input via `getevent`, executado pelo Shizuku (usuário shell). */
class RawInput(private val sink: InputSink) {
    @Volatile var running = false
    private var proc: Process? = null

    fun start(onFail: (String) -> Unit) {
        if (running) return
        running = true
        Thread {
            try {
                val p = ShizukuMgr.spawn(arrayOf("getevent", "-q"))
                proc = p
                val r = p.inputStream.bufferedReader()
                var dx = 0
                var dy = 0
                while (running) {
                    val line = r.readLine() ?: break
                    val t = line.trim().split(' ').filter { it.isNotEmpty() }
                    val o = if (t.isNotEmpty() && t[0].endsWith(":")) 1 else 0
                    if (t.size < o + 3) continue
                    val type = t[o].toIntOrNull(16) ?: continue
                    val code = t[o + 1].toIntOrNull(16) ?: continue
                    val v = (t[o + 2].toLongOrNull(16) ?: continue).toInt()
                    when (type) {
                        1 -> if (code != 330 && v != 2) sink.key(code, v == 1)
                        2 -> when (code) {
                            0 -> dx += v
                            1 -> dy += v
                            8 -> {
                                val c = if (v > 0) Keys.WHEEL_UP else Keys.WHEEL_DOWN
                                if (v != 0) { sink.key(c, true); sink.key(c, false) }
                            }
                        }
                        3 -> if (code < 0x28) sink.abs(code, v)
                        0 -> if (dx != 0 || dy != 0) { sink.rel(dx, dy); dx = 0; dy = 0 }
                    }
                }
            } catch (e: Throwable) {
                if (running) onFail(e.cause?.message ?: e.message ?: "erro")
            } finally {
                running = false
                try { proc?.destroy() } catch (e: Throwable) { /* ignora */ }
            }
        }.start()
    }

    fun stop() {
        running = false
        try { proc?.destroy() } catch (e: Throwable) { /* ignora */ }
    }
}

/** Converte entrada física (teclado/mouse/gamepad) nos toques do perfil ativo. */
class MapEngine(private val inj: TouchInjector, private val prefs: SharedPreferences) : InputSink {
    private val ht = HandlerThread("dm-engine").also { it.start() }
    private val h = Handler(ht.looper)

    @set:JvmName("assignProfile")
    @Volatile var profile: Profile? = null
    @Volatile var paused = false
    @Volatile var screenW = 1920
    @Volatile var screenH = 1080
    @Volatile var onPause: ((Boolean) -> Unit)? = null
    @Volatile var capture: ((Int) -> Unit)? = null

    private val joyKeys = HashSet<Int>()
    private var joyDown = false
    private var anaX = 0f
    private var anaY = 0f
    private var camDown = false
    private var camX = 0f
    private var camY = 0f
    private var ranaX = 0f
    private var ranaY = 0f
    private var tickOn = false
    private var macroBusy = false
    private var hatX = 0
    private var hatY = 0
    private val ranges = HashMap<Int, FloatArray>()

    private val camRelease = Runnable {
        if (camDown) { inj.up(1); camDown = false }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!paused && abs(ranaX) + abs(ranaY) > 0.1f) {
                camMove(ranaX * 14f, ranaY * 14f)
                h.postDelayed(this, 12)
            } else {
                tickOn = false
            }
        }
    }

    private fun px(x: Float) = x * screenW
    private fun py(y: Float) = y * screenH
    private fun minDim() = min(screenW, screenH).toFloat()

    fun setProfile(p: Profile?) {
        h.post { releaseAll(); profile = p; paused = false }
    }

    fun release() {
        h.post { releaseAll() }
    }

    fun shutdown() {
        h.post { releaseAll() }
        ht.quitSafely()
    }

    private fun releaseAll() {
        h.removeCallbacks(camRelease)
        inj.releaseAll()
        joyDown = false
        camDown = false
        joyKeys.clear()
        anaX = 0f; anaY = 0f; ranaX = 0f; ranaY = 0f
    }

    // ---- InputSink (chamado pela thread de leitura; tudo é serializado na thread do motor)

    override fun key(code: Int, down: Boolean) {
        h.post { handleKey(code, down) }
    }

    override fun rel(dx: Int, dy: Int) {
        h.post {
            if (capture == null && !paused) camMove(dx.toFloat(), dy.toFloat())
        }
    }

    override fun abs(code: Int, value: Int) {
        h.post { handleAbs(code, value) }
    }

    private fun handleKey(code: Int, down: Boolean) {
        val cap = capture
        if (cap != null) {
            if (down) { capture = null; cap(code) }
            return
        }
        val p = profile ?: return
        if (down && code == p.pauseKey) {
            paused = !paused
            if (paused) releaseAll()
            onPause?.invoke(paused)
            return
        }
        if (paused) return
        for (i in p.controls.indices) {
            val c = p.controls[i]
            if (!c.on) continue
            when (c.type) {
                CT.BUTTON -> if (c.key == code) {
                    val slot = 2 + (i % 12)
                    if (c.tap) {
                        if (down) tapAt(slot, px(c.x), py(c.y))
                    } else if (down) inj.down(slot, px(c.x), py(c.y)) else inj.up(slot)
                }
                CT.JOYSTICK -> if (code == c.kUp || code == c.kDown || code == c.kLeft || code == c.kRight) {
                    if (down) joyKeys.add(code) else joyKeys.remove(code)
                    updateJoy(c)
                }
                CT.MACRO -> if (c.key == code && down) runMacro(p, c)
            }
        }
    }

    private fun tapAt(slot: Int, x: Float, y: Float) {
        inj.down(slot, x, y)
        h.postDelayed({ inj.up(slot) }, 40)
    }

    private fun norm(code: Int, v: Int): Float {
        var r = ranges[code]
        if (r == null) {
            r = if (v in 0..255) floatArrayOf(0f, 255f) else floatArrayOf(-32768f, 32767f)
            ranges[code] = r
        }
        val f = v.toFloat()
        if (f < r[0]) r[0] = f
        if (f > r[1]) r[1] = f
        val mid = (r[0] + r[1]) / 2f
        val half = (r[1] - r[0]) / 2f
        if (half < 1f) return 0f
        return (f - mid) / half
    }

    private fun handleAbs(code: Int, value: Int) {
        if (capture != null || paused) return
        val dz = prefs.getFloat("deadzone", 0.15f)
        when (code) {
            0, 1 -> {
                val n = norm(code, value)
                val a = if (abs(n) < dz) 0f else n
                if (code == 0) anaX = a else anaY = a
                profile?.controls?.firstOrNull { it.type == CT.JOYSTICK && it.on }?.let { updateJoy(it) }
            }
            2, 3, 4, 5 -> {
                // direito: (3,4) ou (2,5), conforme o controle
                val horizontal = code == 3 || code == 2
                val vertical = code == 4 || code == 5
                val n = norm(code, value)
                val a = if (abs(n) < dz) 0f else n
                if (horizontal) ranaX = a
                if (vertical) ranaY = a
                if (!tickOn && abs(ranaX) + abs(ranaY) > 0.1f) {
                    tickOn = true
                    h.post(ticker)
                }
            }
            16 -> {
                if (hatX < 0) handleKey(Keys.HAT_LEFT, false)
                if (hatX > 0) handleKey(Keys.HAT_RIGHT, false)
                hatX = value
                if (value < 0) handleKey(Keys.HAT_LEFT, true)
                if (value > 0) handleKey(Keys.HAT_RIGHT, true)
            }
            17 -> {
                if (hatY < 0) handleKey(Keys.HAT_UP, false)
                if (hatY > 0) handleKey(Keys.HAT_DOWN, false)
                hatY = value
                if (value < 0) handleKey(Keys.HAT_UP, true)
                if (value > 0) handleKey(Keys.HAT_DOWN, true)
            }
        }
    }

    private fun updateJoy(c: Control) {
        var vx = (if (joyKeys.contains(c.kRight)) 1f else 0f) - (if (joyKeys.contains(c.kLeft)) 1f else 0f)
        var vy = (if (joyKeys.contains(c.kDown)) 1f else 0f) - (if (joyKeys.contains(c.kUp)) 1f else 0f)
        if (vx == 0f && vy == 0f) { vx = anaX; vy = anaY }
        val len = sqrt(vx * vx + vy * vy)
        if (len < 0.08f) {
            if (joyDown) { inj.up(0); joyDown = false }
            return
        }
        if (len > 1f) { vx /= len; vy /= len }
        val cx = px(c.x)
        val cy = py(c.y)
        val r = c.size * minDim() / 2f
        if (!joyDown) { inj.down(0, cx, cy); joyDown = true }
        inj.move(0, cx + vx * r, cy + vy * r)
    }

    private fun camMove(dx: Float, dy: Float) {
        val p = profile ?: return
        val c = p.controls.firstOrNull { it.type == CT.CAMERA && it.on } ?: return
        val cx = px(c.x)
        val cy = py(c.y)
        val r = c.size * minDim() / 2f
        if (!camDown) { inj.down(1, cx, cy); camX = cx; camY = cy; camDown = true }
        val gain = prefs.getFloat("mouseGain", 1f) * 2f
        camX += dx * p.sensH * gain * (if (p.invertX) -1f else 1f)
        camY += dy * p.sensV * gain * (if (p.invertY) -1f else 1f)
        val ddx = camX - cx
        val ddy = camY - cy
        if (ddx * ddx + ddy * ddy > r * r * 0.64f) {
            inj.up(1); inj.down(1, cx, cy)
            camX = cx; camY = cy
        } else {
            inj.move(1, camX, camY)
        }
        h.removeCallbacks(camRelease)
        h.postDelayed(camRelease, 120)
    }

    /** Macro = sequência curta de toques em controles do próprio perfil. Sem repetição automática. */
    fun runMacro(p: Profile, c: Control) {
        h.post {
            if (macroBusy) return@post
            val lines = c.steps.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(12)
            var t = 0L
            var any = false
            for (s in lines) {
                val parts = s.split(",").map { it.trim() }
                val idx = parts.getOrNull(0)?.toIntOrNull() ?: continue
                val hold = (parts.getOrNull(1)?.toLongOrNull() ?: 50L).coerceIn(30L, 2000L)
                val wait = (parts.getOrNull(2)?.toLongOrNull() ?: 100L).coerceIn(50L, 5000L)
                val target = p.controls.getOrNull(idx - 1) ?: continue
                val x = px(target.x)
                val y = py(target.y)
                h.postDelayed({ inj.down(14, x, y) }, t)
                h.postDelayed({ inj.up(14) }, t + hold)
                t += hold + wait
                any = true
            }
            if (any) {
                macroBusy = true
                h.postDelayed({ macroBusy = false }, t + 10)
            }
        }
    }
}
