package com.darkmouse.pro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * ATENÇÃO: este arquivo foi reescrito a partir do uso no resto do código (o original foi
 * sobrescrito por engano). Os campos e o formato JSON seguem o que Editor/Input/Screens/Backup esperam.
 */

/** Códigos de tecla = códigos do Linux evdev, os mesmos que o `getevent` imprime. */
object Keys {
    const val ESC = 1
    const val Q = 16
    const val W = 17
    const val E = 18
    const val R = 19
    const val A = 30
    const val S = 31
    const val D = 32
    const val F = 33
    const val SHIFT = 42
    const val SPACE = 57
    const val F8 = 66
    const val MOUSE_L = 272
    const val MOUSE_R = 273
    const val MOUSE_M = 274

    // pseudo-teclas geradas pelo próprio app (não existem no evdev)
    const val WHEEL_UP = 1001
    const val WHEEL_DOWN = 1002
    const val HAT_UP = 1003
    const val HAT_DOWN = 1004
    const val HAT_LEFT = 1005
    const val HAT_RIGHT = 1006

    val table: Map<Int, String> by lazy {
        val m = LinkedHashMap<Int, String>()
        fun put(first: Int, s: String) { s.forEachIndexed { i, ch -> m[first + i] = ch.toString() } }
        put(2, "1234567890")
        put(16, "QWERTYUIOP")
        put(30, "ASDFGHJKL")
        put(44, "ZXCVBNM")
        for (i in 0..9) m[59 + i] = "F${i + 1}"
        m[87] = "F11"
        m[88] = "F12"
        m[ESC] = "ESC"
        m[15] = "TAB"
        m[28] = "ENTER"
        m[29] = "CTRL"
        m[SHIFT] = "SHIFT"
        m[56] = "ALT"
        m[SPACE] = "ESPAÇO"
        m[14] = "BACKSPACE"
        m[103] = "↑"
        m[105] = "←"
        m[106] = "→"
        m[108] = "↓"
        m[MOUSE_L] = "MOUSE ESQ"
        m[MOUSE_R] = "MOUSE DIR"
        m[MOUSE_M] = "MOUSE MEIO"
        m[275] = "MOUSE 4"
        m[276] = "MOUSE 5"
        m[WHEEL_UP] = "SCROLL ↑"
        m[WHEEL_DOWN] = "SCROLL ↓"
        m[304] = "PAD A"
        m[305] = "PAD B"
        m[307] = "PAD X"
        m[308] = "PAD Y"
        m[310] = "PAD LB"
        m[311] = "PAD RB"
        m[312] = "PAD LT"
        m[313] = "PAD RT"
        m[314] = "PAD SELECT"
        m[315] = "PAD START"
        m[317] = "PAD L3"
        m[318] = "PAD R3"
        m[HAT_UP] = "D-PAD ↑"
        m[HAT_DOWN] = "D-PAD ↓"
        m[HAT_LEFT] = "D-PAD ←"
        m[HAT_RIGHT] = "D-PAD →"
        m
    }

    fun name(code: Int): String = if (code <= 0) "—" else table[code] ?: "K$code"
}

/** Tipos de controle. */
object CT {
    const val BUTTON = 0
    const val JOYSTICK = 1
    const val CAMERA = 2
    const val MACRO = 3

    fun name(t: Int): String = when (t) {
        BUTTON -> "Botão"
        JOYSTICK -> "Joystick"
        CAMERA -> "Câmera"
        MACRO -> "Macro"
        else -> "?"
    }
}

/**
 * Um controle do layout. x,y = centro (fração 0..1 da tela); size = fração do lado menor da tela.
 * BUTTON: `key` + `tap` (toque curto) ou segurar. JOYSTICK: kUp/kLeft/kDown/kRight. CAMERA: mouse/analógico direito.
 * MACRO: `key` dispara `steps` ("n,hold_ms,wait_ms" por linha).
 */
class Control(
    var type: Int,
    var x: Float,
    var y: Float
) {
    var id: String = UUID.randomUUID().toString().take(8)
    var size: Float = 0.1f
    var alpha: Float = 0.8f
    var rot: Float = 0f
    var label: String = ""
    var key: Int = 0
    var kUp: Int = Keys.W
    var kLeft: Int = Keys.A
    var kDown: Int = Keys.S
    var kRight: Int = Keys.D
    var tap: Boolean = false
    var on: Boolean = true
    var steps: String = ""

    fun copy(): Control {
        val c = Control(type, x, y)
        c.size = size; c.alpha = alpha; c.rot = rot; c.label = label; c.key = key
        c.kUp = kUp; c.kLeft = kLeft; c.kDown = kDown; c.kRight = kRight
        c.tap = tap; c.on = on; c.steps = steps
        return c
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id).put("type", type).put("x", x.toDouble()).put("y", y.toDouble())
        o.put("size", size.toDouble()).put("alpha", alpha.toDouble()).put("rot", rot.toDouble())
        o.put("label", label).put("key", key)
        o.put("kUp", kUp).put("kLeft", kLeft).put("kDown", kDown).put("kRight", kRight)
        o.put("tap", tap).put("on", on).put("steps", steps)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Control {
            val c = Control(
                o.optInt("type", CT.BUTTON),
                o.optDouble("x", 0.5).toFloat(),
                o.optDouble("y", 0.5).toFloat()
            )
            c.id = o.optString("id", c.id)
            c.size = o.optDouble("size", 0.1).toFloat()
            c.alpha = o.optDouble("alpha", 0.8).toFloat()
            c.rot = o.optDouble("rot", 0.0).toFloat()
            c.label = o.optString("label", "")
            c.key = o.optInt("key", 0)
            c.kUp = o.optInt("kUp", Keys.W)
            c.kLeft = o.optInt("kLeft", Keys.A)
            c.kDown = o.optInt("kDown", Keys.S)
            c.kRight = o.optInt("kRight", Keys.D)
            c.tap = o.optBoolean("tap", false)
            c.on = o.optBoolean("on", true)
            c.steps = o.optString("steps", "")
            return c
        }
    }
}

class Profile(
    var id: String,
    var name: String,
    var pkg: String,
    var mode: String = "custom"
) {
    val controls: MutableList<Control> = ArrayList()
    var sensH: Float = 1f
    var sensV: Float = 1f
    var invertX: Boolean = false
    var invertY: Boolean = false
    var pauseKey: Int = Keys.F8
    var favorite: Boolean = false
    var updated: Long = 0L

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id).put("name", name).put("pkg", pkg).put("mode", mode)
        o.put("sensH", sensH.toDouble()).put("sensV", sensV.toDouble())
        o.put("invertX", invertX).put("invertY", invertY)
        o.put("pauseKey", pauseKey).put("favorite", favorite).put("updated", updated)
        val a = JSONArray()
        controls.forEach { a.put(it.toJson()) }
        o.put("controls", a)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Profile {
            val p = Profile(
                o.optString("id", UUID.randomUUID().toString().take(8)),
                o.optString("name", "Perfil"),
                o.optString("pkg", ""),
                o.optString("mode", "custom")
            )
            p.sensH = o.optDouble("sensH", 1.0).toFloat()
            p.sensV = o.optDouble("sensV", 1.0).toFloat()
            p.invertX = o.optBoolean("invertX", false)
            p.invertY = o.optBoolean("invertY", false)
            p.pauseKey = o.optInt("pauseKey", Keys.F8)
            p.favorite = o.optBoolean("favorite", false)
            p.updated = o.optLong("updated", 0L)
            val a = o.optJSONArray("controls") ?: JSONArray()
            for (i in 0 until a.length()) p.controls.add(Control.fromJson(a.getJSONObject(i)))
            return p
        }
    }
}

/** Layouts iniciais. O usuário reposiciona tudo no editor, em cima do jogo. */
object Templates {
    private fun btn(p: Profile, x: Float, y: Float, key: Int, size: Float = 0.09f, tap: Boolean = false, label: String = "") {
        val c = Control(CT.BUTTON, x, y)
        c.size = size
        c.key = key
        c.tap = tap
        c.label = label.ifEmpty { Keys.name(key) }
        p.controls.add(c)
    }

    private fun joy(p: Profile) {
        val j = Control(CT.JOYSTICK, 0.16f, 0.70f)
        j.size = 0.30f
        p.controls.add(j)
    }

    fun fps(pkg: String): Profile {
        val p = Profile(UUID.randomUUID().toString().take(8), "FPS", pkg, "FPS")
        joy(p)
        val cam = Control(CT.CAMERA, 0.68f, 0.45f)
        cam.size = 0.35f
        cam.alpha = 0.5f
        p.controls.add(cam)
        btn(p, 0.88f, 0.60f, Keys.MOUSE_L, 0.13f, false, "Atirar")
        btn(p, 0.93f, 0.38f, Keys.SPACE, 0.09f, true, "Pular")
        btn(p, 0.80f, 0.80f, Keys.SHIFT, 0.09f, false, "Correr")
        btn(p, 0.60f, 0.82f, Keys.R, 0.09f, true, "Recarregar")
        return p
    }

    fun moba(pkg: String): Profile {
        val p = Profile(UUID.randomUUID().toString().take(8), "MOBA", pkg, "MOBA")
        joy(p)
        btn(p, 0.86f, 0.74f, Keys.MOUSE_L, 0.13f, true, "Atacar")
        btn(p, 0.74f, 0.80f, Keys.Q, 0.09f, true, "Hab 1")
        btn(p, 0.78f, 0.62f, Keys.W, 0.09f, true, "Hab 2")
        btn(p, 0.92f, 0.58f, Keys.E, 0.09f, true, "Hab 3")
        btn(p, 0.66f, 0.66f, Keys.R, 0.09f, true, "Ultimate")
        return p
    }

    fun custom(pkg: String): Profile =
        Profile(UUID.randomUUID().toString().take(8), "Personalizado", pkg, "Livre")
}

/** Perfis ficam só neste aparelho (SharedPreferences privado). */
class ProfileStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun all(): List<Profile> {
        val s = sp.getString("all", "[]") ?: "[]"
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { Profile.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun write(l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp.edit().putString("all", a.toString()).apply()
    }

    fun forPkg(pkg: String): List<Profile> = all().filter { it.pkg == pkg }

    fun save(p: Profile) {
        p.updated = System.currentTimeMillis()
        val l = all().toMutableList()
        val i = l.indexOfFirst { it.id == p.id }
        if (i >= 0) l[i] = p else l.add(p)
        write(l)
    }

    fun delete(id: String) {
        val p = all().firstOrNull { it.id == id }
        write(all().filter { it.id != id })
        if (p != null && sp.getString("active_" + p.pkg, null) == id) {
            sp.edit().remove("active_" + p.pkg).apply()
        }
    }

    fun duplicate(p: Profile): Profile {
        val c = Profile.fromJson(p.toJson())
        c.id = UUID.randomUUID().toString().take(8)
        c.name = p.name + " (cópia)"
        c.controls.forEach { it.id = UUID.randomUUID().toString().take(8) }
        save(c)
        return c
    }

    fun setActive(p: Profile) {
        sp.edit().putString("active_" + p.pkg, p.id).apply()
    }

    /** Perfil ativo do jogo; se nenhum foi escolhido, o favorito, senão o primeiro. */
    fun activeFor(pkg: String): Profile? {
        val l = forPkg(pkg)
        if (l.isEmpty()) return null
        val id = sp.getString("active_$pkg", null)
        return l.firstOrNull { it.id == id } ?: l.firstOrNull { it.favorite } ?: l.first()
    }
}
